export enum UserRole {
  DONOR = 'DONOR',
  BANK = 'BANK',
  ADMIN = 'ADMIN'
}

export type BloodComponent = 'WHOLE_BLOOD' | 'RBC' | 'PLATELET' | 'PLASMA';

export type TransferStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface User {
  id: string;
  username: string;
  password: string; 
  fullName: string;
  role: UserRole;
  avatarUrl?: string; 
  bloodType?: string;
  location?: string;
  coordinates?: { lat: number; lng: number };
  age?: number;
  weight?: number;
  phone?: string;
  lastDonationDate?: string;
  totalDonations?: number;
  claimableCredits?: number;
}

export interface BloodStock {
  id: string;
  bankId: string;
  bloodType: string;
  component: BloodComponent;
  units: number;
  lastUpdated: string;
}

export interface StockActivity {
  id: string;
  bankId: string;
  action: 'ADD' | 'REMOVE' | 'CONVERT' | 'TRANSFER_OUT' | 'TRANSFER_IN';
  bloodType: string;
  component: BloodComponent;
  units: number;
  timestamp: number;
  relatedPerson?: string; 
  relatedUserId?: string; 
  personType?: 'REGISTERED' | 'UNREGISTERED' | 'HOSPITAL' | 'BANK';
}

export interface BloodTransfer {
  id: string;
  sourceBankId: string;
  sourceBankName: string;
  destBankId: string;
  destBankName: string;
  bloodType: string;
  component: BloodComponent;
  units: number;
  status: TransferStatus;
  timestamp: number;
  initiatedBy: UserRole;
}

export interface DonationRequest {
  id: string;
  bankName: string;
  bloodType: string;
  urgency: 'URGENT' | 'NORMAL';
  location: string;
  coordinates?: { lat: number; lng: number };
  date: string;
  status: 'OPEN' | 'FULFILLED';
  pledgedDonorIds?: string[];
  notifiedDonorIds?: string[];
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  performerName: string;
  timestamp: number;
  type: 'INFO' | 'WARNING' | 'SUCCESS';
}