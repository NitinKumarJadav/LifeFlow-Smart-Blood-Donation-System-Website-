export const DEFAULT_PASSWORD = 'password123';
export const SAFE_DONATION_PERIOD_DAYS = 56;