import { User, DonationRequest } from '../types';

interface MatchedDonor {
  id: string;
  fullName: string;
  phone: string;
  bloodType: string;
  location: string;
  lastDonationDate: string | null;
  coordinates: { lat: number; lng: number };
  distanceKm: number;
  compatibilityLabel: string;
}

const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lng2 - lng1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ; 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const d = R * c; // Distance in km
  return Math.round(d * 100) / 100;
};

const deg2rad = (deg: number) => deg * (Math.PI/180);

const isFitForDonation = (lastDonationDate?: string): boolean => {
  if (!lastDonationDate) return true;
  const last = new Date(lastDonationDate);
  const diffTime = Math.abs(new Date().getTime() - last.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays >= 56; // Standard 56 days between donations
};

export const matchEmergencyDonorsLocal = (
  request: DonationRequest,
  allUsers: User[]
) => {
  // Modified: Only filter donors with the exact same blood group as requested
  const matchedDonors: MatchedDonor[] = allUsers
    .filter(u => u.role === 'DONOR' && u.bloodType === request.bloodType)
    .filter(u => isFitForDonation(u.lastDonationDate))
    .map(u => {
      const distance = (request.coordinates && u.coordinates) 
        ? calculateDistance(request.coordinates.lat, request.coordinates.lng, u.coordinates.lat, u.coordinates.lng)
        : 999;
      
      const label = u.bloodType === 'O-' ? 'Universal Donor' : 'Exact Match';

      return {
        id: u.id,
        fullName: u.fullName,
        phone: u.phone || 'N/A',
        bloodType: u.bloodType || '?',
        location: u.location || 'Unknown',
        lastDonationDate: u.lastDonationDate || null,
        coordinates: u.coordinates || { lat: 0, lng: 0 },
        distanceKm: distance,
        compatibilityLabel: label
      };
    })
    .sort((a, b) => a.distanceKm - b.distanceKm)
    .slice(0, 15);

  return {
    requestId: request.id,
    bloodType: request.bloodType,
    matchedDonors,
    urgency: request.urgency,
    timestamp: Date.now(),
  };
};