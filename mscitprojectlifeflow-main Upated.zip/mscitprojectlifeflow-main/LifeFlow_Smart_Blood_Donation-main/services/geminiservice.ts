import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

export const getAIResponse = async (userMessage: string, context: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const systemInstruction = `You are LifeFlow AI, a specialized assistant for a smart blood donation platform.
    Help donors, banks, and admins manage life-saving resources.
    
    Current User Context:
    ${context}

    Rules:
    - Keep answers concise and medically accurate.
    - Be encouraging to donors.
    - If asked about inventory specifics you don't have, ask them to check the "Hub Matrix" in their dashboard.
    - Follow WHO blood donation guidelines.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });

    return response.text || "I'm having trouble processing that right now.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "The grid is busy. Please try asking again in a moment.";
  }
};