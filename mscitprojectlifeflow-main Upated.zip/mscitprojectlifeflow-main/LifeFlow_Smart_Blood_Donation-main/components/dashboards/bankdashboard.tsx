import React, { useState } from 'react';
import { User, BloodStock, DonationRequest, StockActivity, AuditLog, UserRole, BloodComponent, BloodTransfer } from '../../types';
import { CircleAlert as AlertCircle, Plus, RefreshCcw, Network, Trash2, CreditCard as Edit2, History, ListFilter as Filter, UserPlus, Megaphone, Droplet, Map as MapIcon, Hand, UserCheck, ShieldCheck, User as UserIcon, Building2, Activity, Zap, Navigation, ArrowLeftRight, Search, FlaskConical } from 'lucide-react';
import GoogleMap from '../googlemap';
import ConfirmModal from '../modals/confirmmodal';
import Tooltip from '../ui/tooltip';

interface BankDashboardProps {
  currentUser: User;
  allUsers: User[];
  stock: BloodStock[];
  requests: DonationRequest[];
  activities: StockActivity[];
  transfers: BloodTransfer[];
  logs: AuditLog[];
  onOpenRequestModal: (initialData?: Partial<DonationRequest>) => void;
  onOpenStockModal: () => void;
  onOpenTransferModal: () => void;
  onDeleteRequest: (id: string) => void;
  onOpenUserModal: (user?: User) => void;
  onDeleteUser: (id: string) => void;
  onProcessBlood?: (bankId: string, bloodType: string) => void;
}

const BankDashboard: React.FC<BankDashboardProps> = ({ 
  currentUser, allUsers, stock, requests, activities, transfers, logs,
  onOpenRequestModal, onOpenStockModal, onOpenTransferModal, onDeleteRequest, onOpenUserModal, onDeleteUser, onProcessBlood
}) => {
  const [tab, setTab] = useState<'overview' | 'inventory' | 'transfers' | 'donors' | 'map' | 'history'>('overview');
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'STOCK' | 'USER' | 'REQUEST' | 'TRANSFER'>('ALL');
  const [donorSearchQuery, setDonorSearchQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  // Data Filtering
  const myStock = stock.filter(s => s.bankId === currentUser.id);
  const myRequests = requests.filter(r => r.bankName === currentUser.fullName);
  const allDonors = allUsers.filter(u => u.role === UserRole.DONOR);
  
  const filteredDonors = allDonors.filter(donor => 
    donor.fullName.toLowerCase().includes(donorSearchQuery.toLowerCase()) ||
    donor.bloodType?.toLowerCase().includes(donorSearchQuery.toLowerCase())
  );

  const myActivities = activities.filter(a => a.bankId === currentUser.id);
  const myTransfers = transfers.filter(t => t.sourceBankId === currentUser.id || t.destBankId === currentUser.id);

  const allBloodTypes = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
  const components: BloodComponent[] = ['WHOLE_BLOOD', 'RBC', 'PLATELET', 'PLASMA'];

  const handleProcess = async (bloodType: string) => {
    if (!onProcessBlood) return;
    setIsProcessing(bloodType);
    // Simulate processing delay for UX feedback
    await new Promise(r => setTimeout(r, 600));
    onProcessBlood(currentUser.id, bloodType);
    setIsProcessing(null);
  };

  // Unified History Logic
  const combinedHistory = [
    ...logs.map(l => ({
      id: l.id,
      category: l.action.includes('STOCK') || l.action.includes('COMPONENT') ? 'STOCK' as const : l.action.includes('USER') ? 'USER' as const : l.action.includes('TRANSFER') ? 'TRANSFER' as const : 'REQUEST' as const,
      label: l.action.replace(/_/g, ' '),
      details: l.details,
      performer: l.performerName,
      timestamp: l.timestamp,
      status: l.type as 'INFO' | 'WARNING' | 'SUCCESS'
    })),
    ...myActivities.map(a => ({
      id: a.id,
      category: 'STOCK' as const,
      label: `INVENTORY ${a.action}`,
      details: `${a.action === 'ADD' ? 'Received' : 'Issued'} ${a.units}u of ${a.bloodType} ${a.component.replace('_', ' ')} (${a.relatedPerson})`,
      performer: currentUser.fullName,
      timestamp: a.timestamp,
      status: (a.action === 'ADD' ? 'SUCCESS' : 'INFO') as 'INFO' | 'WARNING' | 'SUCCESS'
    }))
  ].sort((a, b) => b.timestamp - a.timestamp);

  const filteredHistory = combinedHistory.filter(item => {
    if (historyFilter === 'ALL') return true;
    return item.category === historyFilter;
  });

  // Map Markers
  const donorMarkers = allDonors.filter(u => u.coordinates).map(u => ({ id: u.id, lat: u.coordinates!.lat, lng: u.coordinates!.lng, title: u.fullName, type: 'DONOR' as const }));
  const requestMarkers = requests.filter(r => r.status === 'OPEN' && r.coordinates).map(r => ({ 
    id: r.id, 
    lat: r.coordinates!.lat, 
    lng: r.coordinates!.lng, 
    title: r.bankName, 
    type: 'REQUEST' as const,
    bloodType: r.bloodType,
    urgency: r.urgency,
    date: r.date
  }));
  const otherBanks = allUsers.filter(u => u.role === UserRole.BANK && u.id !== currentUser.id && u.coordinates).map(u => ({ id: u.id, lat: u.coordinates!.lat, lng: u.coordinates!.lng, title: u.fullName, type: 'BANK' as const }));
  const myMarker = currentUser.coordinates ? [{ id: currentUser.id, lat: currentUser.coordinates.lat, lng: currentUser.coordinates.lng, title: 'Your Hub', type: 'BANK' as const }] : [];
  const mapMarkers: any[] = [...donorMarkers, ...requestMarkers, ...otherBanks, ...myMarker];
  const mapCenter = currentUser.coordinates || { lat: 40.7128, lng: -74.0060 };

  const commonDropdownStyle = {
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7' /%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat', backgroundPosition: 'right 0.75rem center', backgroundSize: '1.25rem'
  };
  const commonDropdownClass = "bg-white border-2 border-gray-100 text-sm font-black text-gray-700 rounded-2xl py-3 pl-5 pr-10 focus:ring-4 focus:ring-red-100/50 focus:border-red-500 cursor-pointer outline-none appearance-none shadow-sm transition-all hover:border-gray-300 active:scale-[0.99]";

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 animate-fade-in relative">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 tracking-tight leading-tight">Hub Management</h2>
          <p className="text-gray-500 font-medium mt-1">Component logistics & node connectivity</p>
        </div>
        <div className="flex bg-white p-1 rounded-xl border border-gray-200 shadow-sm overflow-x-auto">
            {(['overview', 'inventory', 'transfers', 'donors', 'map', 'history'] as const).map(t => (
              <button key={t} onClick={() => setTab(t)} className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${tab === t ? 'bg-red-600 text-white shadow-md' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'} capitalize flex items-center whitespace-nowrap`}>
                {t}
              </button>
            ))}
        </div>
      </div>

      {tab === 'overview' && (
        <div className="animate-slide-up space-y-6">
           <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <button onClick={onOpenStockModal} className="bg-white hover:bg-red-50 p-6 rounded-[2rem] border border-gray-100 shadow-sm transition-all group text-left active:scale-95">
                 <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><RefreshCcw className="w-6 h-6 text-red-600" /></div>
                 <h4 className="text-lg font-bold text-gray-900 leading-tight">Inventory</h4>
                 <p className="text-sm text-gray-500 mt-1">Manage local units.</p>
              </button>
              <button onClick={onOpenTransferModal} className="bg-white hover:bg-purple-50 p-6 rounded-[2rem] border border-gray-100 shadow-sm transition-all group text-left active:scale-95">
                 <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><ArrowLeftRight className="w-6 h-6 text-purple-600" /></div>
                 <h4 className="text-lg font-bold text-gray-900 leading-tight">Transfer</h4>
                 <p className="text-sm text-gray-500 mt-1">Move blood to other hubs.</p>
              </button>
              <button onClick={() => onOpenRequestModal({ coordinates: currentUser.coordinates })} className="bg-white hover:bg-blue-50 p-6 rounded-[2rem] border border-gray-100 shadow-sm transition-all group text-left active:scale-95">
                 <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><Megaphone className="w-6 h-6 text-blue-600" /></div>
                 <h4 className="text-lg font-bold text-gray-900 leading-tight">Campaign</h4>
                 <p className="text-sm text-gray-500 mt-1">Broadcast emergencies.</p>
              </button>
              <button onClick={() => onOpenUserModal()} className="bg-white hover:bg-green-50 p-6 rounded-[2rem] border border-gray-100 shadow-sm transition-all group text-left active:scale-95">
                 <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><UserPlus className="w-6 h-6 text-green-600" /></div>
                 <h4 className="text-lg font-bold text-gray-900 leading-tight">Onboard</h4>
                 <p className="text-sm text-gray-500 mt-1">Register new donors.</p>
              </button>
           </div>
           
           <div className="bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-sm">
             <div className="flex justify-between items-center mb-8">
               <h4 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Activity className="w-5 h-5 text-red-500" /> Hub Matrix</h4>
             </div>
             <div className="space-y-6">
                {allBloodTypes.map(type => {
                   const typeStock = myStock.filter(s => s.bloodType === type);
                   const total = typeStock.reduce((acc, curr) => acc + curr.units, 0);
                   return (
                     <div key={type} className="flex flex-col gap-2">
                        <div className="flex justify-between items-end">
                           <span className="text-lg font-black text-gray-900">{type} System Load</span>
                           <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{total} Total Units</span>
                        </div>
                        <div className="grid grid-cols-4 gap-2">
                           {components.map(comp => {
                              const item = typeStock.find(s => s.component === comp);
                              const units = item ? item.units : 0;
                              const isLow = units < 10 && units > 0;
                              const canProcess = comp === 'WHOLE_BLOOD' && units > 0;

                              return (
                                <div key={comp} className={`relative p-3 rounded-2xl border flex flex-col items-center transition-all group/tile ${isLow ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-100'}`}>
                                   <span className={`text-[8px] font-black uppercase tracking-tighter mb-1 ${isLow ? 'text-red-400' : 'text-gray-400'}`}>{comp.replace('_', ' ')}</span>
                                   <span className={`text-lg font-black ${isLow ? 'text-red-600' : 'text-gray-900'}`}>{units}</span>
                                   
                                   {canProcess && (
                                     <div className="absolute inset-0 bg-white/40 backdrop-blur-[2px] opacity-0 group-hover/tile:opacity-100 flex items-center justify-center transition-all rounded-2xl">
                                        <Tooltip content={`Convert 1u ${type} Whole Blood`}>
                                           <button 
                                             onClick={() => handleProcess(type)}
                                             disabled={isProcessing === type}
                                             className="bg-blue-600 text-white p-2 rounded-xl shadow-lg active:scale-90 transition-transform hover:bg-blue-700"
                                           >
                                             <FlaskConical className={`w-4 h-4 ${isProcessing === type ? 'animate-spin' : ''}`} />
                                           </button>
                                        </Tooltip>
                                     </div>
                                   )}
                                </div>
                              )
                           })}
                        </div>
                     </div>
                   )
                })}
             </div>
           </div>
        </div>
      )}

      {tab === 'inventory' && (
        <div className="animate-slide-up space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-sm">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-900">Hub Component Inventory</h3>
                <button onClick={onOpenStockModal} className="bg-gray-900 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-black transition-all active:scale-95 flex items-center gap-2"><Zap className="w-4 h-4" /> New Entry</button>
             </div>
             <div className="bg-white border border-gray-100 rounded-[1.5rem] overflow-hidden overflow-x-auto">
                <table className="w-full text-left min-w-[500px]">
                   <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>
                         <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400">Class</th>
                         <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400">Component</th>
                         <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400 text-center">Available Units</th>
                         <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400 text-right">Utility</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-gray-50">
                      {myStock.sort((a,b) => a.bloodType.localeCompare(b.bloodType)).map(item => {
                         const isLow = item.units < 10;
                         const isCurrentProcessing = isProcessing === item.bloodType && item.component === 'WHOLE_BLOOD';
                         return (
                         <tr key={item.id} className={`hover:bg-gray-50 transition-colors ${isLow ? 'bg-red-50/30' : ''}`}>
                            <td className="px-6 py-4 font-black text-red-600 text-lg">{item.bloodType}</td>
                            <td className="px-6 py-4 text-xs font-bold text-gray-700">{item.component.replace('_', ' ')}</td>
                            <td className={`px-6 py-4 text-center font-black text-xl ${isLow ? 'text-red-700' : 'text-gray-900'}`}>
                               <div className="inline-flex flex-col items-center">
                                  {item.units}
                                  {isLow && <span className="text-[8px] uppercase tracking-widest text-red-500 font-black leading-none mt-1">Low Stock</span>}
                               </div>
                            </td>
                            <td className="px-6 py-4 text-right">
                               {item.component === 'WHOLE_BLOOD' && item.units > 0 && (
                                  <button 
                                    onClick={() => handleProcess(item.bloodType)} 
                                    disabled={!!isProcessing}
                                    className="px-4 py-2 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-blue-700 transition-all shadow-md active:scale-95 flex items-center gap-2 ml-auto disabled:opacity-50"
                                  >
                                    <RefreshCcw className={`w-3 h-3 ${isCurrentProcessing ? 'animate-spin' : ''}`} /> 
                                    {isCurrentProcessing ? 'Processing' : 'Convert'}
                                  </button>
                               )}
                            </td>
                         </tr>
                      )})}
                   </tbody>
                </table>
             </div>
          </div>
        </div>
      )}

      {tab === 'transfers' && (
        <div className="animate-slide-up space-y-6">
           <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm">
              <div>
                 <h3 className="text-xl font-bold text-gray-900">Transfer Pipeline</h3>
                 <p className="text-gray-500 text-sm font-medium">Outbound transfers require Admin approval.</p>
              </div>
              <button onClick={onOpenTransferModal} className="bg-purple-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-purple-200 hover:bg-purple-700 transition-all active:scale-95 flex items-center gap-2"><ArrowLeftRight className="w-5 h-5" /> Request Transfer</button>
           </div>
           <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
              <table className="w-full text-left min-w-[600px]">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Movement</th>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Units</th>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                   {myTransfers.map(t => (
                     <tr key={t.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-3">
                              <div className={`p-2 rounded-lg ${t.sourceBankId === currentUser.id ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                                 {t.sourceBankId === currentUser.id ? <Zap className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
                              </div>
                              <div>
                                 <p className="text-sm font-bold text-gray-900 leading-tight">{t.sourceBankId === currentUser.id ? `To: ${t.destBankName}` : `From: ${t.sourceBankName}`}</p>
                                 <p className="text-[10px] text-gray-400 font-bold uppercase">{t.sourceBankId === currentUser.id ? 'OUTBOUND' : 'INBOUND'}</p>
                              </div>
                           </div>
                        </td>
                        <td className="px-6 py-4 font-black text-gray-700">
                           {t.units}u {t.bloodType} {t.component.replace('_', ' ')}
                        </td>
                        <td className="px-6 py-4">
                           <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border ${
                             t.status === 'APPROVED' ? 'bg-green-50 text-green-700 border-green-100' :
                             t.status === 'REJECTED' ? 'bg-red-50 text-red-700 border-red-100' :
                             'bg-orange-50 text-orange-700 border-orange-100'
                           }`}>{t.status}</span>
                        </td>
                        <td className="px-6 py-4 text-right text-[10px] text-gray-400 font-black uppercase">
                           {new Date(t.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </td>
                     </tr>
                   ))}
                   {myTransfers.length === 0 && <tr><td colSpan={4} className="p-12 text-center text-gray-400 font-bold uppercase text-xs">No Recent Movements</td></tr>}
                </tbody>
              </table>
           </div>
        </div>
      )}

      {tab === 'donors' && (
        <div className="animate-slide-up space-y-6">
           <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <h3 className="text-xl font-bold text-gray-900 whitespace-nowrap">Verified Member Registry</h3>
              <div className="flex-1 max-w-md relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-red-500 transition-colors" />
                <input 
                  type="text" 
                  placeholder="Search by name or blood type..." 
                  value={donorSearchQuery}
                  onChange={(e) => setDonorSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-red-100 text-sm font-medium text-gray-900 placeholder:text-gray-400"
                />
              </div>
              <button onClick={() => onOpenUserModal()} className="bg-red-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-red-200 hover:bg-red-700 active:scale-95 flex items-center gap-2 whitespace-nowrap"><Plus className="w-5 h-5" /> Add Member</button>
           </div>
           <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
                <table className="w-full text-left min-w-[600px]">
                  <thead className="bg-gray-50 border-b border-gray-100">
                    <tr>
                      <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Individual</th>
                      <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-center">Group</th>
                      <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredDonors.map(u => (
                      <tr key={u.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-gray-200 overflow-hidden">{u.avatarUrl ? <img src={u.avatarUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-gray-100 text-gray-400"><UserIcon className="w-1/2 h-1/2" /></div>}</div>
                            <div>
                              <p className="font-bold text-gray-900 text-sm leading-none">{u.fullName}</p>
                              <p className="text-[10px] text-gray-400 font-bold mt-1 uppercase">@{u.username}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center"><span className="font-black text-red-600 bg-red-50 px-2.5 py-1 rounded-lg text-xs">{u.bloodType}</span></td>
                        <td className="px-6 py-4">
                           <div className="flex justify-end gap-1.5 whitespace-nowrap">
                             <Tooltip content="Edit Record"><button onClick={() => onOpenUserModal(u)} className="p-2 text-gray-400 hover:text-blue-600 rounded-xl transition-all"><Edit2 className="w-4 h-4" /></button></Tooltip>
                             <Tooltip content="Archive Account"><button onClick={() => promptDeleteUser(u)} className="p-2 text-gray-400 hover:text-red-600 rounded-xl transition-all"><Trash2 className="w-4 h-4" /></button></Tooltip>
                           </div>
                        </td>
                      </tr>
                    ))}
                    {filteredDonors.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-6 py-12 text-center">
                          <p className="text-gray-400 font-medium text-sm">No donors match your search.</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
           </div>
        </div>
      )}

      {tab === 'map' && (
        <div className="animate-slide-up space-y-4">
           <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm h-[600px]">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2"><Navigation className="w-5 h-5 text-blue-600" /> Operational Grid View</h3>
              <div className="h-[500px] rounded-[1.5rem] overflow-hidden border border-gray-200">
                <GoogleMap center={mapCenter} zoom={12} markers={mapMarkers} />
              </div>
           </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="animate-slide-up space-y-6">
           <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
             <div className="flex items-center gap-3">
               <div className="p-2 bg-gray-100 text-gray-500 rounded-lg"><History className="w-5 h-5" /></div>
               <h3 className="font-bold text-gray-900 tracking-tight">Hub History Stream</h3>
             </div>
             <div className="w-full sm:w-72">
               <select value={historyFilter} onChange={(e) => setHistoryFilter(e.target.value as any)} className={commonDropdownClass} style={commonDropdownStyle}>
                 <option value="ALL">Entire Pipeline</option>
                 <option value="STOCK">Inventory Logs</option>
                 <option value="TRANSFER">Transfer Logs</option>
                 <option value="USER">User Auth</option>
                 <option value="REQUEST">Campaign Flow</option>
               </select>
             </div>
           </div>
           <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
              <table className="w-full text-left min-w-[700px]">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Entry Class</th>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Description</th>
                    <th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {filteredHistory.map(item => (
                    <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-1">
                          <span className={`w-fit px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-tighter border ${
                             item.category === 'STOCK' ? 'bg-purple-50 text-purple-700 border-purple-100' :
                             item.category === 'USER' ? 'bg-blue-50 text-blue-700 border-blue-100' :
                             item.category === 'TRANSFER' ? 'bg-yellow-50 text-yellow-700 border-yellow-100' :
                             'bg-orange-50 text-orange-700 border-orange-100'
                          }`}>{item.category}</span>
                          <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border ${
                             item.status === 'SUCCESS' ? 'bg-green-50 text-green-700 border-green-100' :
                             item.status === 'WARNING' ? 'bg-red-50 text-red-700 border-red-100' :
                             'bg-gray-50 text-gray-600 border-gray-200'
                          }`}>{item.label}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-xs font-bold text-gray-900 leading-tight">{item.details}</p>
                        <p className="text-[10px] text-gray-400 font-bold mt-1 uppercase tracking-tight">Auth: {item.performer}</p>
                      </td>
                      <td className="px-6 py-4 text-right text-[10px] text-gray-400 font-black uppercase">
                        {new Date(item.timestamp).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
           </div>
        </div>
      )}

      <ConfirmModal isOpen={confirmModal.isOpen} onClose={() => setConfirmModal(prev => ({...prev, isOpen: false}))} onConfirm={confirmModal.onConfirm} title={confirmModal.title} message={confirmModal.message} isDanger={confirmModal.isDanger} confirmText="Authorize" />
    </div>
  );
};

export default BankDashboard;