import React, { useState } from 'react';
import { User, DonationRequest, StockActivity, UserRole } from '../../types';
import { Heart, Activity, MapPin, Droplet, Clock, CheckCircle, Gift, ArrowRight, Navigation, Zap, Building2 } from 'lucide-react';
import GoogleMap from '../googlemap';

interface DonorDashboardProps {
  currentUser: User;
  allUsers: User[];
  requests: DonationRequest[];
  activities: StockActivity[];
  onRespondToRequest: (id: string) => void;
}

const DonorDashboard: React.FC<DonorDashboardProps> = ({ currentUser, allUsers, requests, activities, onRespondToRequest }) => {
  const [showRedeemInfo, setShowRedeemInfo] = useState(false);

  const myActivities = activities
    .filter(a => a.relatedUserId === currentUser.id)
    .sort((a, b) => b.timestamp - a.timestamp);
  
  const handlePledge = (id: string) => {
    onRespondToRequest(id);
  };

  const handleNavigate = (location: string) => {
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`, '_blank');
  };
  
  const mapCenter = currentUser.coordinates || { lat: 40.7128, lng: -74.0060 };
  
  const bankMarkers = allUsers
    .filter(u => u.role === UserRole.BANK && u.coordinates)
    .map(u => ({
      id: u.id,
      lat: u.coordinates!.lat,
      lng: u.coordinates!.lng,
      title: u.fullName,
      type: 'BANK' as const
    }));

  const requestMarkers = requests
    .filter(r => r.status === 'OPEN' && r.coordinates)
    .map(r => ({
      id: r.id,
      lat: r.coordinates!.lat,
      lng: r.coordinates!.lng,
      title: r.bankName,
      type: 'REQUEST' as const,
      bloodType: r.bloodType,
      urgency: r.urgency,
      date: r.date
    }));
    
  const mapMarkers: any[] = [...bankMarkers, ...requestMarkers];
    
  if (currentUser.coordinates) {
    mapMarkers.push({
        id: currentUser.id,
        lat: currentUser.coordinates.lat,
        lng: currentUser.coordinates.lng,
        title: "Registered Sector",
        type: 'DONOR' as const
    });
  }

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 animate-fade-in relative">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 tracking-tight leading-none uppercase tracking-tighter">Welcome back, {currentUser.fullName.split(' ')[0]}!</h2>
          <p className="text-gray-500 font-medium mt-1 uppercase tracking-widest text-[11px]">
            {currentUser.location ? `Grid Sector Active: ${currentUser.location}` : 'Sector Map Pending...'}
          </p>
        </div>
        <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-red-100 flex items-center gap-2">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Blood Type</span>
            <span className="text-xl font-black text-red-600">{currentUser.bloodType || 'N/A'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-red-500 to-red-600 p-6 rounded-[2rem] text-white shadow-lg shadow-red-200 hover:scale-[1.02] transition-transform">
           <div className="flex items-start justify-between mb-8">
             <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm">
               <Heart className="w-6 h-6 text-white" />
             </div>
             <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest backdrop-blur-sm">Lifetime</span>
           </div>
           <div>
             <span className="text-4xl font-black">{currentUser.totalDonations || 0}</span>
             <span className="text-red-100 ml-2 font-black uppercase text-xs tracking-widest">Donations</span>
           </div>
        </div>

        <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
           <div className="absolute right-[-20px] top-[-20px] p-3 opacity-5 group-hover:opacity-10 transition-opacity rotate-12">
              <Gift className="w-32 h-32 text-blue-600" />
           </div>
           <div className="flex items-start justify-between mb-6 relative z-10">
             <div className="p-3 bg-blue-50 rounded-2xl">
               <Activity className="w-6 h-6 text-blue-600" />
             </div>
             <button 
               onClick={() => setShowRedeemInfo(!showRedeemInfo)}
               className="bg-blue-100 hover:bg-blue-200 px-3 py-1 rounded-full text-[10px] font-black text-blue-700 transition-colors uppercase tracking-widest"
             >
               Redeem Info
             </button>
           </div>
           <div className="relative z-10">
             <span className="text-4xl font-black text-gray-900">{currentUser.claimableCredits || 0}</span>
             <span className="text-gray-400 ml-2 font-black uppercase text-xs tracking-widest">Credits</span>
             <p className="text-[11px] text-gray-500 mt-2 font-medium leading-relaxed">
                Redeemable at any hub. <span className="font-black text-blue-600">1 Unit = 1 Credit</span>
             </p>
           </div>
           
           {showRedeemInfo && (
             <div className="absolute inset-0 bg-white/98 backdrop-blur-sm z-20 p-6 flex flex-col justify-center animate-fade-in text-center">
                <h4 className="font-black text-gray-900 mb-2 uppercase tracking-widest text-sm">Redemption Protocol</h4>
                <p className="text-xs text-gray-500 mb-4 font-medium leading-relaxed">
                  Visit any registered hub and provide your ID. Blood is issued instantly against your credit balance.
                </p>
                <button 
                  onClick={() => setShowRedeemInfo(false)}
                  className="mx-auto text-[10px] font-black text-blue-600 hover:underline uppercase tracking-widest"
                >
                  Dismiss
                </button>
             </div>
           )}
        </div>

        <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm">
           <div className="flex items-start justify-between mb-8">
             <div className="p-3 bg-green-50 rounded-2xl">
               <Clock className="w-6 h-6 text-green-600" />
             </div>
           </div>
           <div>
             <span className="text-[10px] font-black text-gray-400 uppercase block mb-1 tracking-widest">Last Activity</span>
             <span className="text-xl font-black text-gray-900">{currentUser.lastDonationDate || 'First Action Pending'}</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-black text-gray-900 flex items-center gap-2 uppercase tracking-tighter">
            <Droplet className="w-5 h-5 text-red-500 fill-current" />
            Active Camps Nearby
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             {requests.filter(r => r.status === 'OPEN').map(req => {
               const isPledged = req.pledgedDonorIds && req.pledgedDonorIds.includes(currentUser.id);
               const isNotified = req.notifiedDonorIds && req.notifiedDonorIds.includes(currentUser.id);
               const isBloodMatch = currentUser.bloodType === req.bloodType;
               
               return (
               <div key={req.id} className={`bg-white p-5 rounded-[1.5rem] border shadow-sm hover:shadow-md transition-all group relative overflow-hidden flex flex-col justify-between ${isNotified ? 'border-amber-200 ring-2 ring-amber-100 bg-amber-50/10' : 'border-gray-100'}`}>
                 <div className="flex justify-between items-start">
                    <div className={`px-3 py-1 rounded-full font-black text-[10px] tracking-widest uppercase ${req.urgency === 'URGENT' ? 'bg-red-500 text-white' : 'bg-blue-600 text-white'}`}>
                    {req.urgency}
                    </div>
                    {isNotified && (
                        <div className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full font-black text-[10px] uppercase tracking-widest flex items-center gap-1.5 animate-pulse">
                            <Zap className="w-3 h-3 fill-current" /> Direct Alert
                        </div>
                    )}
                 </div>
                 <div className="mt-4">
                    <h4 className="font-black text-gray-900 pr-14 text-lg leading-tight uppercase tracking-tighter">{req.bankName}</h4>
                    <div className="mt-4 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                        <Droplet className={`w-4 h-4 ${isBloodMatch ? 'text-green-500' : 'text-red-500'}`} />
                        <span className={`uppercase tracking-widest ${isBloodMatch ? 'text-green-700 font-black' : ''}`}>Required: {req.bloodType}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-gray-400 font-bold uppercase tracking-tight">
                        <MapPin className="w-4 h-4" />
                        {req.location}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-gray-400 font-bold uppercase tracking-tight">
                        <Clock className="w-4 h-4" />
                        {req.date}
                        </div>
                    </div>
                 </div>
                 
                 <div className="flex gap-2 mt-5">
                    {isBloodMatch && (
                        <button 
                           onClick={() => !isPledged && handlePledge(req.id)}
                           disabled={!!isPledged}
                           className={`flex-1 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2 active:scale-95 ${
                             isPledged 
                             ? 'bg-green-100 text-green-700 cursor-default shadow-none border border-green-200' 
                             : 'bg-gray-900 text-white hover:bg-black hover:shadow-lg'
                           }`}
                        >
                           {isPledged ? (
                             <>
                                <CheckCircle className="w-4 h-4" /> Pledge Logged
                             </>
                           ) : "Accept Mission"}
                        </button>
                    )}
                    {req.location && (
                         <button 
                           onClick={() => handleNavigate(req.location)}
                           className={`flex-1 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2 active:scale-95 border-2 border-gray-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200 text-gray-500 ${!isBloodMatch ? 'w-full bg-gray-50' : ''}`}
                         >
                            <Navigation className="w-4 h-4" /> Navigate
                         </button>
                    )}
                 </div>
               </div>
             )})}
             {requests.filter(r => r.status === 'OPEN').length === 0 && (
               <div className="col-span-2 p-12 text-center bg-gray-50/50 rounded-[2rem] text-gray-400 border border-dashed border-gray-200 font-bold text-sm uppercase tracking-widest">
                 Static Grid: No Active Campaigns
               </div>
             )}
          </div>
        </div>

        <div className="space-y-6">
           <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter">Your Journal</h3>
           <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 h-[450px] overflow-hidden flex flex-col">
              {myActivities.length > 0 ? (
                <div className="flex-1 overflow-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="sticky top-0 bg-gray-50/95 backdrop-blur-sm z-10 border-b border-gray-100">
                      <tr>
                        <th className="px-4 py-3 text-[10px] font-black uppercase text-gray-400 tracking-widest">Date</th>
                        <th className="px-4 py-3 text-[10px] font-black uppercase text-gray-400 tracking-widest">Activity</th>
                        <th className="px-4 py-3 text-[10px] font-black uppercase text-gray-400 tracking-widest">Source Hub</th>
                        <th className="px-4 py-3 text-[10px] font-black uppercase text-gray-400 tracking-widest text-right">Load</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {myActivities.map(act => {
                        const isDonation = act.action === 'ADD';
                        const bankName = allUsers.find(u => u.id === act.bankId)?.fullName || 'HUB ARCHIVE';
                        return (
                            <tr key={act.id} className="hover:bg-gray-50/50 transition-colors group">
                                <td className="px-4 py-4 whitespace-nowrap">
                                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">
                                    {new Date(act.timestamp).toLocaleDateString()}
                                  </p>
                                </td>
                                <td className="px-4 py-4">
                                  <div className="flex items-center gap-2">
                                    <div className={`w-1.5 h-1.5 rounded-full ${isDonation ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                                    <span className={`text-[10px] font-black uppercase tracking-widest ${isDonation ? 'text-gray-900' : 'text-blue-900'}`}>
                                        {isDonation ? 'Donation' : 'Redemption'}
                                    </span>
                                  </div>
                                </td>
                                <td className="px-4 py-4">
                                  <div className="flex items-center gap-1.5">
                                    <Building2 className="w-3 h-3 text-gray-300" />
                                    <p className="text-[10px] text-gray-600 font-black uppercase tracking-tighter truncate max-w-[100px]">
                                      {bankName}
                                    </p>
                                  </div>
                                </td>
                                <td className="px-4 py-4 text-right whitespace-nowrap">
                                  <div className={`text-sm font-black leading-none ${isDonation ? 'text-green-600' : 'text-blue-600'}`}>
                                      {isDonation ? '+' : '-'}{act.units}
                                  </div>
                                  <div className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{act.bloodType}</div>
                                </td>
                            </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center p-8">
                  <div className="w-14 h-14 bg-gray-50 rounded-full flex items-center justify-center mb-4 border border-gray-100">
                     <Clock className="w-6 h-6 text-gray-200" />
                  </div>
                  <p className="text-gray-400 text-xs font-black uppercase tracking-widest">Log Empty</p>
                </div>
              )}
           </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-xl space-y-4">
        <h3 className="text-xl font-black text-gray-900 flex items-center gap-2 uppercase tracking-tighter">
            <MapPin className="w-5 h-5 text-red-500" />
            Operational Network Map
        </h3>
        <div className="h-[450px] rounded-[1.5rem] overflow-hidden border border-gray-100 shadow-inner">
             <GoogleMap 
                 center={mapCenter}
                 zoom={12}
                 markers={mapMarkers}
               />
        </div>
      </div>
    </div>
  );
};

export default DonorDashboard;