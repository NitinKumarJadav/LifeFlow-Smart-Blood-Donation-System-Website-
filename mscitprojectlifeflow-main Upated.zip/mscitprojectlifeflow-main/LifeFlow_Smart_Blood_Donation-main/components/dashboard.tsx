import React, { useState } from 'react';
import { User, UserRole, BloodStock, DonationRequest, StockActivity, AuditLog, BloodComponent, BloodTransfer } from '../types';
import { Droplet, LogOut, User as UserIcon, Building2, ShieldCheck, ArrowLeftRight } from 'lucide-react';
import { DEFAULT_PASSWORD } from '../constants';
import DonorDashboard from './dashboards/donordashboard';
import BankDashboard from './dashboards/bankdashboard';
import AdminDashboard from './dashboards/admindashboard';
import UserModal from './modals/usermodal';
import RequestModal from './modals/requestmodal';
import StockModal from './modals/stockmodal';
import ProfileModal from './modals/profilemodal';
import TransferModal from './modals/transfermodal';
import PaymentModal from './modals/paymentmodal';

interface DashboardProps {
  currentUser: User;
  allUsers: User[];
  stock: BloodStock[];
  requests: DonationRequest[];
  activities: StockActivity[];
  transfers: BloodTransfer[];
  logs: AuditLog[];
  onLogout: () => void;
  onAddUser: (u: User) => void;
  onUpdateUser: (u: User) => void;
  onDeleteUser: (id: string) => void;
  onResetPassword: (id: string) => void;
  onStockTransaction: (bankId: string, bloodType: string, units: number, action: 'ADD' | 'REMOVE', relatedPerson?: string, personType?: 'REGISTERED' | 'UNREGISTERED' | 'HOSPITAL' | 'BANK', relatedUserId?: string, component?: BloodComponent) => void;
  onTransferRequest: (transfer: Omit<BloodTransfer, 'id' | 'status' | 'timestamp' | 'sourceBankName' | 'destBankName'>) => void;
  onApproveTransfer: (id: string) => void;
  onRejectTransfer: (id: string) => void;
  onAddRequest: (r: DonationRequest) => void;
  onUpdateRequest: (r: DonationRequest) => void;
  onDeleteRequest: (id: string) => void;
  onRespondToRequest: (id: string) => void;
  onProcessBlood?: (bankId: string, bloodType: string) => void;
  onNotifyDonor?: (requestId: string, donorId: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  currentUser, allUsers, stock, requests, activities, transfers, logs, onLogout,
  onAddUser, onUpdateUser, onDeleteUser, onResetPassword, onStockTransaction,
  onTransferRequest, onApproveTransfer, onRejectTransfer,
  onAddRequest, onUpdateRequest, onDeleteRequest, onRespondToRequest, onProcessBlood, onNotifyDonor
}) => {
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [requestInitData, setRequestInitData] = useState<Partial<DonationRequest>>({});
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [pendingIssuance, setPendingIssuance] = useState<any>(null);

  const handleOpenUserModal = (user?: User) => {
    setEditingUser(user || null);
    setIsUserModalOpen(true);
  };

  const handleSaveUser = (formData: Partial<User>) => {
    if (editingUser) {
      onUpdateUser({ ...editingUser, ...formData } as User);
    } else {
      const newUser: User = {
        id: Date.now().toString(),
        username: formData.username!,
        password: formData.password || DEFAULT_PASSWORD,
        fullName: formData.fullName!,
        role: formData.role!,
        location: formData.location || '',
        avatarUrl: formData.avatarUrl,
        bloodType: formData.role === UserRole.DONOR ? formData.bloodType : undefined,
        age: formData.age,
        weight: formData.weight,
        phone: formData.phone,
        totalDonations: 0,
        claimableCredits: 0
      };
      onAddUser(newUser);
    }
    setIsUserModalOpen(false);
  };

  const handleOpenRequestModal = (initialData?: Partial<DonationRequest>) => {
    setRequestInitData({
      urgency: 'NORMAL',
      bloodType: 'O+',
      date: new Date().toISOString().split('T')[0],
      location: currentUser.location || '',
      coordinates: currentUser.coordinates,
      ...initialData
    });
    setIsRequestModalOpen(true);
  };

  const handleSaveRequest = (formData: Partial<DonationRequest>) => {
    if (!formData.bloodType || !formData.date || !formData.urgency) return;
    const newRequest: DonationRequest = {
      id: Date.now().toString(),
      bankName: currentUser.fullName,
      status: 'OPEN',
      bloodType: formData.bloodType!,
      date: formData.date!,
      location: formData.location || '',
      coordinates: formData.coordinates,
      urgency: formData.urgency! as 'URGENT' | 'NORMAL'
    };
    onAddRequest(newRequest);
    setIsRequestModalOpen(false);
  };

  const handleStockAction = (bankId: string, bloodType: string, units: number, action: 'ADD' | 'REMOVE', relatedPerson?: string, personType?: any, relatedUserId?: string, component?: BloodComponent) => {
    if (action === 'REMOVE') {
      // Show payment modal first for issuance
      setPendingIssuance({ bankId, bloodType, units, action, relatedPerson, personType, relatedUserId, component });
      setIsPaymentModalOpen(true);
      setIsStockModalOpen(false);
    } else {
      onStockTransaction(bankId, bloodType, units, action, relatedPerson, personType, relatedUserId, component);
    }
  };

  const finalizePendingIssuance = () => {
    if (pendingIssuance) {
      onStockTransaction(
        pendingIssuance.bankId,
        pendingIssuance.bloodType,
        pendingIssuance.units,
        pendingIssuance.action,
        pendingIssuance.relatedPerson,
        pendingIssuance.personType,
        pendingIssuance.relatedUserId,
        pendingIssuance.component
      );
      setPendingIssuance(null);
    }
    setIsPaymentModalOpen(false);
  };

  const handleSaveProfile = (data: Partial<User>, newPassword?: string) => {
    const updatedUser = { ...currentUser, ...data };
    if (newPassword && newPassword.trim()) updatedUser.password = newPassword;
    onUpdateUser(updatedUser);
    setIsProfileModalOpen(false);
  };

  const renderAvatar = (user: User, className = "w-full h-full object-cover") => {
    if (user.avatarUrl) return <img src={user.avatarUrl} alt="Avatar" className={className} />;
    const iconClass = "w-1/2 h-1/2 text-gray-400";
    return (
      <div className={`w-full h-full flex items-center justify-center bg-gray-100 ${className.includes('rounded') ? '' : 'rounded-full'}`}>
        {user.role === UserRole.ADMIN ? <ShieldCheck className={iconClass} /> :
         user.role === UserRole.BANK ? <Building2 className={iconClass} /> :
         <UserIcon className={iconClass} />}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#fef2f2]">
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-red-100 shadow-sm px-4 py-3 md:px-8 flex justify-between items-center transition-all">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-red-500 to-red-600 p-2.5 rounded-xl shadow-lg shadow-red-200">
            <div className="animate-pulse"><Droplet className="w-5 h-5 text-white fill-current" /></div>
          </div>
          <div>
            <h1 className="font-bold text-xl text-gray-900 tracking-tight leading-none">LifeFlow</h1>
            <p className="text-[10px] text-red-500 font-bold tracking-widest uppercase mt-0.5 opacity-80">
              {currentUser.role.replace('_', ' ')} PORTAL
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setIsProfileModalOpen(true)} className="flex items-center gap-3 hover:bg-gray-100 p-1.5 pr-4 rounded-full transition-all group text-left">
            <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden ring-2 ring-white shadow-sm group-hover:ring-red-200 transition-all">
               {renderAvatar(currentUser)}
            </div>
            <div className="hidden md:block">
              <p className="text-sm font-bold text-gray-800 leading-tight group-hover:text-red-600 transition-colors">{currentUser.fullName}</p>
              <p className="text-xs text-gray-500 font-medium">
                {currentUser.location ? `Node: ${currentUser.location}` : 'Map Your Hub'}
              </p>
            </div>
          </button>
          <div className="h-8 w-[1px] bg-gray-200 hidden md:block"></div>
          <button onClick={onLogout} className="p-2.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all active:scale-95" title="Logout">
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="pb-24 relative z-0">
        {currentUser.role === UserRole.DONOR && (
          <DonorDashboard currentUser={currentUser} allUsers={allUsers} requests={requests} activities={activities} onRespondToRequest={onRespondToRequest} />
        )}
        
        {currentUser.role === UserRole.BANK && (
          <BankDashboard 
            currentUser={currentUser} allUsers={allUsers} stock={stock} requests={requests} activities={activities} transfers={transfers} logs={logs}
            onOpenRequestModal={handleOpenRequestModal} onOpenStockModal={() => setIsStockModalOpen(true)} onOpenTransferModal={() => setIsTransferModalOpen(true)}
            onDeleteRequest={onDeleteRequest} onOpenUserModal={handleOpenUserModal} onDeleteUser={onDeleteUser}
            onProcessBlood={onProcessBlood}
          />
        )}

        {currentUser.role === UserRole.ADMIN && (
          <AdminDashboard 
            allUsers={allUsers} stock={stock} requests={requests} transfers={transfers} logs={logs}
            onOpenUserModal={handleOpenUserModal} onDeleteUser={onDeleteUser} onResetPassword={onResetPassword}
            onDeleteRequest={onDeleteRequest} onOpenRequestModal={handleOpenRequestModal} onOpenTransferModal={() => setIsTransferModalOpen(true)}
            onApproveTransfer={onApproveTransfer} onRejectTransfer={onRejectTransfer}
            onNotifyDonor={onNotifyDonor}
          />
        )}
      </main>
      
      <UserModal isOpen={isUserModalOpen} onClose={() => setIsUserModalOpen(false)} currentUser={currentUser} editingUser={editingUser} onSave={handleSaveUser} />
      <StockModal 
        isOpen={isStockModalOpen} 
        onClose={() => setIsStockModalOpen(false)} 
        currentUser={currentUser} 
        allUsers={allUsers} 
        myStock={stock.filter(s => s.bankId === currentUser.id)} 
        onConfirm={handleStockAction}
      />
      <TransferModal isOpen={isTransferModalOpen} onClose={() => setIsTransferModalOpen(false)} currentUser={currentUser} allUsers={allUsers} stock={stock} onConfirm={onTransferRequest} />
      <RequestModal isOpen={isRequestModalOpen} onClose={() => setIsRequestModalOpen(false)} initialData={requestInitData} onSave={handleSaveRequest} />
      <ProfileModal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} currentUser={currentUser} onSave={handleSaveProfile} />
      <PaymentModal 
        isOpen={isPaymentModalOpen} 
        onClose={() => { setIsPaymentModalOpen(false); setPendingIssuance(null); }} 
        onSuccess={finalizePendingIssuance}
        amount={pendingIssuance ? `${pendingIssuance.units} Units` : undefined}
      />
    </div>
  );
};

export default Dashboard;