import React, { useState, useEffect, useRef } from 'react';
import { X, Lock, Upload, Image as ImageIcon, MapPin, User as UserIcon, Building2, ShieldCheck, Phone } from 'lucide-react';
import { User, UserRole } from '../../types';
import { DEFAULT_PASSWORD } from '../../constants';
import GoogleMap from '../googlemap';

interface UserModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  editingUser: User | null;
  onSave: (user: Partial<User>) => void;
}

const allBloodTypes = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

const UserModal: React.FC<UserModalProps> = ({ isOpen, onClose, currentUser, editingUser, onSave }) => {
  const [formData, setFormData] = useState<Partial<User>>({});
  const [errors, setErrors] = useState<{ phone?: string }>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingUser) setFormData({ ...editingUser });
    else setFormData({ role: UserRole.DONOR, bloodType: 'O+', password: DEFAULT_PASSWORD, coordinates: { lat: 40.7128, lng: -74.0060 } });
    setErrors({});
  }, [editingUser, currentUser, isOpen]);

  if (!isOpen) return null;

  const validatePhone = (p?: string) => {
    if (!p) return false;
    return /^\+?[\d\s-]{10,15}$/.test(p);
  };

  const handleSave = () => {
    if (!validatePhone(formData.phone)) {
        setErrors({ phone: 'Invalid phone format' });
        return;
    }
    onSave(formData);
  };

  const handleMapClick = (lat: number, lng: number) => setFormData(prev => ({ ...prev, coordinates: { lat, lng } }));

  const availableRoles = (Object.values(UserRole) as UserRole[]).filter(role => role !== UserRole.ADMIN);

  const dropdownStyle = {
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7' /%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat', backgroundPosition: 'right 0.75rem center', backgroundSize: '1.25rem'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-slide-up max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h3 className="font-black text-gray-900 uppercase tracking-widest text-sm">Account Matrix</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors"><X className="w-5 h-5 text-gray-400" /></button>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Username</label>
                <input type="text" value={formData.username || ''} onChange={(e) => setFormData({...formData, username: e.target.value})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900 text-sm" placeholder="ID code" />
             </div>
             <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Full Legal Name</label>
                <input type="text" value={formData.fullName || ''} onChange={(e) => setFormData({...formData, fullName: e.target.value})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900 text-sm" placeholder="Full name" />
             </div>
          </div>
          
          {currentUser.role === UserRole.ADMIN && (
            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Network Role</label>
              <div className="flex gap-2 mt-2">
                {availableRoles.map(role => (
                  <button key={role} onClick={() => setFormData({...formData, role})} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border-2 transition-all ${formData.role === role ? 'bg-gray-900 text-white border-gray-900 shadow-md' : 'bg-white text-gray-400 border-gray-100'}`}>
                    {role.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div>
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1 block mb-2">HUB Geolocation</label>
              <div className="h-[180px] w-full rounded-2xl overflow-hidden border-2 border-gray-100 shadow-lg shadow-black/5">
                  <GoogleMap center={formData.coordinates || { lat: 40.7128, lng: -74.0060 }} zoom={13} markers={formData.coordinates ? [{ id: 'new', lat: formData.coordinates.lat, lng: formData.coordinates.lng, title: 'Target', type: 'DONOR' }] : []} onMapClick={handleMapClick} hideGlobalMarkers={true} />
              </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div>
                <label className={`text-[10px] font-black uppercase tracking-widest ml-1 ${errors.phone ? 'text-red-500' : 'text-gray-400'}`}>Secure Phone</label>
                <input type="text" value={formData.phone || ''} onChange={(e) => {setFormData({...formData, phone: e.target.value}); setErrors({}); }} className={`w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 font-bold text-gray-900 text-sm ${errors.phone ? 'ring-2 ring-red-500 bg-red-50' : 'focus:ring-red-100'}`} placeholder="+91-XXX-XXX-XXXX" />
             </div>
             {formData.role === UserRole.DONOR && (
               <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Current Age</label>
                  <input type="number" value={formData.age || ''} onChange={(e) => setFormData({...formData, age: parseInt(e.target.value) || undefined})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900 text-sm" placeholder="YY" />
               </div>
             )}
          </div>

          {formData.role === UserRole.DONOR && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Weight (KG)</label>
                <input type="number" value={formData.weight || ''} onChange={(e) => setFormData({...formData, weight: parseInt(e.target.value) || undefined})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900 text-sm" placeholder="KK" />
              </div>
              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Blood Group</label>
                <select value={formData.bloodType} onChange={(e) => setFormData({...formData, bloodType: e.target.value})} style={dropdownStyle} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-2 border-transparent focus:border-red-500 focus:bg-white focus:ring-4 focus:ring-red-100/50 outline-none appearance-none font-bold text-gray-900 text-sm transition-all shadow-sm pr-10 cursor-pointer">
                   {allBloodTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
          )}
        </div>
        <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
           <button onClick={onClose} className="px-6 py-3 font-black text-[10px] uppercase text-gray-400">Discard</button>
           <button onClick={handleSave} className="px-10 py-3 bg-gray-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:shadow-black/20 transition-all active:scale-95">Verify & Save</button>
        </div>
      </div>
    </div>
  );
};

export default UserModal;