import React, { useState } from 'react';
import { X, Phone, MapPin, Droplet, Clock, AlertCircle, Send, Check } from 'lucide-react';

interface MatchedDonor {
  id: string;
  fullName: string;
  phone: string;
  bloodType: string;
  location: string;
  lastDonationDate: string | null;
  coordinates: { lat: number; lng: number };
  distanceKm: number;
  compatibilityLabel: string;
}

interface EmergencyMatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  matchedDonors: MatchedDonor[];
  bloodType: string;
  urgency: string;
  onNotifyDonor: (donorId: string) => void;
}

const EmergencyMatchModal: React.FC<EmergencyMatchModalProps> = ({
  isOpen, onClose, matchedDonors, bloodType, urgency, onNotifyDonor
}) => {
  const [notifiedDonors, setNotifiedDonors] = useState<Set<string>>(new Set());

  if (!isOpen) return null;

  const handleNotify = (donorId: string) => {
    onNotifyDonor(donorId);
    setNotifiedDonors(prev => new Set([...prev, donorId]));
  };

  const getLastDonationStatus = (date: string | null) => {
    if (!date) return { text: 'Available Now', color: 'bg-green-50 text-green-700' };
    const days = Math.floor((Date.now() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
    return { text: `Ready (${days}d since last)`, color: 'bg-blue-50 text-blue-700' };
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-fade-in">
        <div className="bg-gradient-to-r from-red-500 to-red-600 p-8 border-b border-red-400 flex justify-between items-start text-white">
          <div>
            <h2 className="text-3xl font-black flex items-center gap-3 tracking-tighter uppercase">
              <AlertCircle className="w-8 h-8 text-white" />
              Strategic Match
            </h2>
            <p className="text-red-100 font-bold mt-2 uppercase tracking-widest text-xs opacity-90">
              {matchedDonors.length} Potential compatible candidates for {bloodType} ({urgency})
            </p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-xl transition-all">
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 bg-gray-50/50 p-6">
          {matchedDonors.length === 0 ? (
            <div className="p-12 text-center">
              <div className="p-6 bg-white rounded-3xl inline-block mb-4 shadow-sm border border-gray-100">
                <AlertCircle className="w-12 h-12 text-gray-300" />
              </div>
              <p className="text-gray-400 font-black uppercase tracking-widest text-sm">No Grid Matches Found</p>
              <p className="text-xs text-gray-400 mt-2 font-medium">Verify system radius or donor registries.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {matchedDonors.map((donor, index) => {
                const lastDonation = getLastDonationStatus(donor.lastDonationDate);
                const isNotified = notifiedDonors.has(donor.id);

                return (
                  <div
                    key={donor.id}
                    className="bg-white border border-gray-100 rounded-[1.5rem] p-5 hover:shadow-xl transition-all group relative overflow-hidden ring-1 ring-black/[0.02]"
                  >
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-2xl bg-gray-900 text-white flex items-center justify-center flex-shrink-0 font-black text-lg">
                          {donor.bloodType}
                        </div>
                        <div>
                          <h3 className="font-black text-gray-900 text-lg leading-none mb-1">{donor.fullName}</h3>
                          <div className="flex items-center gap-2">
                             <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                               donor.compatibilityLabel === 'Exact Match' ? 'bg-green-100 text-green-700' : 
                               donor.compatibilityLabel === 'Universal Donor' ? 'bg-purple-100 text-purple-700' : 
                               'bg-blue-100 text-blue-700'
                             }`}>
                               {donor.compatibilityLabel}
                             </span>
                             <span className="text-[10px] text-gray-400 font-bold uppercase">• {donor.location}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-black text-red-600 leading-none">{donor.distanceKm} <span className="text-[10px] uppercase text-gray-400">km</span></p>
                        <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest mt-1">PROXIMITY</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-4 items-center justify-between pt-4 border-t border-gray-50">
                      <div className="flex gap-4">
                         <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-gray-400" />
                            <span className={`text-[10px] font-black uppercase ${lastDonation.color.split(' ')[1]}`}>{lastDonation.text}</span>
                         </div>
                         <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-gray-400" />
                            <span className="text-[10px] font-bold text-gray-600 font-mono tracking-tighter">{donor.phone}</span>
                         </div>
                      </div>

                      <button
                        onClick={() => handleNotify(donor.id)}
                        disabled={isNotified}
                        className={`px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 transition-all active:scale-95 shadow-lg ${
                          isNotified
                            ? 'bg-green-100 text-green-700 cursor-default shadow-none'
                            : 'bg-red-600 text-white hover:bg-red-700 shadow-red-200'
                        }`}
                      >
                        {isNotified ? (
                          <><Check className="w-4 h-4" /> Notified</>
                        ) : (
                          <><Send className="w-3.5 h-3.5" /> Dispatch Alert</>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-gray-100 border-t border-gray-200 p-5 text-center">
          <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.2em]">
            System Priority: {urgency} • Grid Sync: Active
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmergencyMatchModal;