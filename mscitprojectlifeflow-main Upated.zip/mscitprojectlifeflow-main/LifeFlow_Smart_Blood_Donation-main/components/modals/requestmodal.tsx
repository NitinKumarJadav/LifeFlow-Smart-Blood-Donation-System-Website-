import React, { useState, useEffect } from 'react';
import { X, Plus, Calendar, MapPin, Navigation } from 'lucide-react';
import { DonationRequest } from '../../types';
import GoogleMap from '../googlemap';

interface RequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialData?: Partial<DonationRequest>;
  onSave: (data: Partial<DonationRequest>) => void;
}

const allBloodTypes = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

const RequestModal: React.FC<RequestModalProps> = ({ isOpen, onClose, initialData, onSave }) => {
  const [formData, setFormData] = useState<Partial<DonationRequest>>({});

  useEffect(() => {
    setFormData({
      urgency: 'NORMAL',
      bloodType: 'O+',
      date: new Date().toISOString().split('T')[0],
      location: '',
      coordinates: initialData?.coordinates || { lat: 40.7128, lng: -74.0060 },
      ...initialData
    });
  }, [initialData, isOpen]);

  const handleMapClick = (lat: number, lng: number) => {
    setFormData(prev => ({ ...prev, coordinates: { lat, lng } }));
  };

  if (!isOpen) return null;

  const mapMarkers = formData.coordinates ? [{
    id: 'new',
    lat: formData.coordinates.lat,
    lng: formData.coordinates.lng,
    title: 'Camp Location',
    type: 'REQUEST' as const
  }] : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-slide-up max-h-[95vh] flex flex-col">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h3 className="font-black text-gray-900 uppercase tracking-widest text-sm flex items-center gap-2">
            <Plus className="w-5 h-5" /> Launch Blood Camp
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
           <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Requirement Matrix</label>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {allBloodTypes.map(type => (
                  <button
                    key={type}
                    onClick={() => setFormData({...formData, bloodType: type})}
                    className={`py-2 rounded-xl text-xs font-black border-2 transition-all ${
                      formData.bloodType === type 
                      ? 'bg-red-600 text-white border-red-600 shadow-md' 
                      : 'bg-white text-gray-400 border-gray-50 hover:border-red-200'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Priority Level</label>
                <div className="flex gap-2 mt-2">
                  {(['NORMAL', 'URGENT'] as const).map(u => (
                    <button
                      key={u}
                      onClick={() => setFormData({...formData, urgency: u})}
                      className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase border-2 transition-all ${
                        formData.urgency === u 
                        ? (u === 'URGENT' ? 'bg-red-500 text-white border-red-500 shadow-sm' : 'bg-blue-600 text-white border-blue-600 shadow-sm')
                        : 'bg-white text-gray-400 border-gray-50 hover:border-gray-200'
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                 <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Activation Date</label>
                 <div className="relative mt-2">
                    <input 
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({...formData, date: e.target.value})}
                      className="w-full p-2.5 pl-10 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900 text-xs"
                    />
                    <Calendar className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                 </div>
              </div>
           </div>

           <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1 flex items-center gap-2 mb-2">
                 <Navigation className="w-3 h-3" /> Pinpoint Camp Hub
              </label>
              <div className="h-[240px] w-full rounded-[1.5rem] overflow-hidden border-2 border-gray-100 shadow-inner">
                 <GoogleMap 
                   center={formData.coordinates || { lat: 40.7128, lng: -74.0060 }}
                   zoom={13}
                   markers={mapMarkers}
                   onMapClick={handleMapClick}
                 />
              </div>
              <p className="text-[10px] text-gray-400 font-bold text-center mt-2 uppercase tracking-tighter">Click to select activation coordinates</p>
           </div>

           <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Regional Hub Name</label>
              <div className="relative mt-2">
                 <input 
                  type="text"
                  value={formData.location || ''}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  className="w-full p-3 pl-10 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900 text-sm"
                  placeholder="e.g. Central Medical Plaza"
                 />
                 <MapPin className="w-5 h-5 text-gray-300 absolute left-3 top-3" />
              </div>
           </div>
        </div>
        
        <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
           <button onClick={onClose} className="px-6 py-3 font-black text-[10px] uppercase tracking-widest text-gray-400 hover:text-gray-900 transition-colors">Discard</button>
           <button onClick={() => onSave(formData)} className="px-10 py-3 bg-gray-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:shadow-black/20 transition-all active:scale-95">
             Activate Camp
           </button>
        </div>
      </div>
    </div>
  );
};

export default RequestModal;