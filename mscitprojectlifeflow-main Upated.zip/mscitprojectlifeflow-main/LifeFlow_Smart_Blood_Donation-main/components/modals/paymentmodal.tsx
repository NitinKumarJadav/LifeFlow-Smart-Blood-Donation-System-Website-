import React from 'react';
import { X, QrCode, ShieldCheck, Copy, Check, Info, Lock } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  amount?: string;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSuccess, amount }) => {
  const [copied, setCopied] = React.useState(false);
  
  if (!isOpen) return null;

  const upiId = "jadavnitin115-1@okicici";
  const name = "Nitin Jadav";

  const handleCopy = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop with blur */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-md animate-fade-in" 
        onClick={onClose}
      />
      
      {/* Modal Container */}
      <div className="bg-white rounded-[2.5rem] w-full max-w-sm shadow-2xl overflow-hidden animate-slide-up relative z-10 border border-gray-100 flex flex-col">
        
        {/* Header - Material 3 Style */}
        <div className="bg-neutral-900 p-6 text-white relative">
          <button 
            onClick={onClose}
            className="absolute right-4 top-4 p-2 hover:bg-white/10 rounded-full transition-all active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex flex-col items-center text-center pt-4">
            <div className="w-16 h-16 bg-red-600 rounded-[1.25rem] flex items-center justify-center mb-4 shadow-lg shadow-red-500/20 animate-pulse-slow">
              <QrCode className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-black uppercase tracking-tight leading-tight">Secure Withdrawal</h3>
            <p className="text-neutral-400 text-[10px] font-black uppercase tracking-[0.2em] mt-1">
              {amount ? `Authorization for ${amount}` : 'Transaction Node Alpha'}
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-8 flex flex-col items-center bg-white">
          {/* QR Code Container */}
          <div className="bg-white p-5 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-neutral-50 mb-8 group transition-all hover:scale-[1.02] hover:shadow-[0_25px_60px_rgba(0,0,0,0.15)] active:scale-[0.98] cursor-pointer">
            <img 
              src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&cu=INR`} 
              alt="UPI QR Code" 
              className="w-44 h-44 select-none"
            />
          </div>

          {/* Receiver Info */}
          <div className="w-full space-y-3">
            <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-100 flex items-center justify-between group transition-colors hover:bg-neutral-100">
              <div>
                <p className="text-[9px] font-black text-neutral-400 uppercase tracking-widest">Authorized Receiver</p>
                <p className="text-sm font-bold text-neutral-900">{name}</p>
              </div>
              <div className="p-2 bg-emerald-100 rounded-lg">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
              </div>
            </div>

            <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-100 flex items-center justify-between group transition-colors hover:bg-neutral-100">
              <div className="truncate pr-4">
                <p className="text-[9px] font-black text-neutral-400 uppercase tracking-widest">UPI Identifier</p>
                <p className="text-xs font-mono font-bold text-neutral-600 truncate">{upiId}</p>
              </div>
              <button 
                onClick={handleCopy}
                className="p-2.5 bg-white shadow-sm border border-neutral-200 rounded-xl transition-all hover:border-neutral-900 hover:text-neutral-900 text-neutral-400 active:scale-90"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="mt-8 flex gap-3 p-4 bg-blue-50 rounded-2xl border border-blue-100 w-full">
            <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <p className="text-[10px] text-blue-700 font-bold leading-relaxed uppercase tracking-tight">
              Scan with any UPI application. Blood will be officially issued from the grid once transaction is verified.
            </p>
          </div>
        </div>

        {/* Footer Action */}
        <div className="p-6 pt-0 bg-white">
           <button 
            onClick={() => onSuccess?.()}
            className="w-full py-4 bg-red-600 text-white rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] shadow-xl hover:bg-red-700 transition-all active:scale-95 flex items-center justify-center gap-2"
           >
             <Lock className="w-3.5 h-3.5" /> Complete Secure Issuance
           </button>
           <button 
            onClick={onClose}
            className="w-full py-3 mt-2 text-neutral-400 font-black uppercase text-[9px] tracking-widest hover:text-neutral-900 transition-colors"
           >
             Abort Transaction
           </button>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes pulse-slow {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.9; transform: scale(1.05); }
        }
        .animate-pulse-slow {
          animation: pulse-slow 3s infinite ease-in-out;
        }
      `}} />
    </div>
  );
};

export default PaymentModal;