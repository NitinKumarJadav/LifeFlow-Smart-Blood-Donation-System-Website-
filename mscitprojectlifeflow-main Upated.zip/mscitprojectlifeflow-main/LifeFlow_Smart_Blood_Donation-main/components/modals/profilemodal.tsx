import React, { useState, useRef } from 'react';
import { X, User as UserIcon, Lock, Eye, EyeOff, Upload, Camera, MapPin, Building2, ShieldCheck } from 'lucide-react';
import { User, UserRole } from '../../types';
import GoogleMap from '../googlemap';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onSave: (data: Partial<User>, newPass?: string) => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, currentUser, onSave }) => {
  const [profileData, setProfileData] = useState<Partial<User>>({...currentUser});
  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [errors, setErrors] = useState<{ phone?: string }>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const validatePhone = (p?: string) => {
    if (!p) return false;
    return /^\+?[\d\s-]{10,15}$/.test(p);
  };

  const handleSave = () => {
    if (!validatePhone(profileData.phone)) {
        setErrors({ phone: 'Invalid phone format' });
        return;
    }
    onSave(profileData, newPassword);
  };

  const handleMapClick = (lat: number, lng: number) => setProfileData(prev => ({ ...prev, coordinates: { lat, lng } }));

  const mapCenter = profileData.coordinates || { lat: 40.7128, lng: -74.0060 };
  const mapMarkers = profileData.coordinates ? [{ id: 'me', lat: profileData.coordinates.lat, lng: profileData.coordinates.lng, title: 'My HUB', type: (currentUser.role === UserRole.BANK ? 'BANK' : 'DONOR') as any }] : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
        <div className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-slide-up max-h-[90vh] overflow-y-auto">
           <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <h3 className="font-black text-gray-900 uppercase tracking-widest text-sm flex items-center gap-2"><UserIcon className="w-5 h-5" /> Account Identity</h3>
            <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors"><X className="w-5 h-5 text-gray-500" /></button>
          </div>
          
          <div className="p-6 space-y-4">
             <div className="flex flex-col items-center mb-6">
                <div onClick={() => fileInputRef.current?.click()} className="w-24 h-24 rounded-full bg-gray-100 border-4 border-white shadow-lg overflow-hidden mb-3 relative group cursor-pointer">
                   {profileData.avatarUrl ? <img src={profileData.avatarUrl} alt="Avatar" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-gray-100"><UserIcon className="w-1/2 h-1/2 text-gray-400" /></div>}
                   <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><Camera className="w-8 h-8 text-white" /></div>
                </div>
                <input type="file" ref={fileInputRef} onChange={(e) => { const file = e.target.files?.[0]; if (file) { const reader = new FileReader(); reader.onloadend = () => setProfileData(prev => ({ ...prev, avatarUrl: reader.result as string })); reader.readAsDataURL(file); } }} accept="image/*" className="hidden" />
             </div>

             <div className="grid grid-cols-2 gap-4">
               <div>
                  <label className="text-[10px] font-black text-gray-500 uppercase ml-1">Full Legal Name</label>
                  <input type="text" value={profileData.fullName || ''} onChange={(e) => setProfileData({...profileData, fullName: e.target.value})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900" />
               </div>
               <div>
                  <label className="text-[10px] font-black text-gray-500 uppercase ml-1">Hub Location</label>
                  <input type="text" value={profileData.location || ''} onChange={(e) => setProfileData({...profileData, location: e.target.value})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900" />
               </div>
             </div>

             <div className="relative">
                <label className="text-[10px] font-black text-gray-500 uppercase ml-1 flex items-center gap-2 mb-2"><MapPin className="w-3 h-3" /> Grid Synchronization</label>
                <div className="h-[200px] w-full rounded-2xl overflow-hidden border border-gray-200 shadow-xl shadow-black/10 transition-shadow">
                    <GoogleMap center={mapCenter} zoom={13} markers={mapMarkers} onMapClick={handleMapClick} hideGlobalMarkers={true} />
                </div>
                <p className="text-[10px] text-gray-400 mt-3 text-center font-black uppercase tracking-widest">
                  {profileData.coordinates ? 'Sector Locked. Click map to reposition.' : 'Define your Grid Sector by clicking the map'}
                </p>
             </div>

             <div className="grid grid-cols-2 gap-4">
               <div>
                  <label className={`text-[10px] font-black uppercase ml-1 ${errors.phone ? 'text-red-500' : 'text-gray-500'}`}>Verified Phone</label>
                  <input type="text" value={profileData.phone || ''} onChange={(e) => {setProfileData({...profileData, phone: e.target.value}); setErrors({}); }} className={`w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 font-bold text-gray-900 ${errors.phone ? 'ring-2 ring-red-500 bg-red-50' : 'focus:ring-red-100'}`} />
               </div>
               {currentUser.role === UserRole.DONOR && (
                  <div>
                      <label className="text-[10px] font-black text-gray-500 uppercase ml-1">Age</label>
                      <input type="number" value={profileData.age || ''} onChange={(e) => setProfileData({...profileData, age: parseInt(e.target.value) || undefined})} className="w-full mt-1 p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900" />
                   </div>
               )}
             </div>

             <div className="pt-4 border-t border-gray-100">
               <label className="text-[10px] font-black text-gray-500 uppercase ml-1 flex items-center gap-2"><Lock className="w-3 h-3" /> Secure Access</label>
               <div className="relative mt-1">
                 <input type={showNewPassword ? "text" : "password"} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="w-full p-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-red-100 font-bold text-gray-900" placeholder="New Access Secret" />
                  <button type="button" onClick={() => setShowNewPassword(!showNewPassword)} className="absolute right-3 top-3 text-gray-400 hover:text-gray-600">{showNewPassword ? <EyeOff className="w-4 h-4"/> : <Eye className="w-4 h-4"/>}</button>
               </div>
             </div>
          </div>

          <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
             <button onClick={onClose} className="px-6 py-3 font-black text-[10px] uppercase text-gray-500">Close</button>
             <button onClick={handleSave} className="px-8 py-3 bg-red-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-red-200 hover:bg-red-700 active:scale-95 transition-all">Verify Credentials</button>
          </div>
        </div>
      </div>
  );
};

export default ProfileModal;