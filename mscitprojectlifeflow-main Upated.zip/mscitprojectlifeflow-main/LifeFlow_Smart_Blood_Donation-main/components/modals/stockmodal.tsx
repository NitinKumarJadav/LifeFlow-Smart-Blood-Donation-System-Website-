import React, { useState, useEffect } from 'react';
import { X, AlertCircle, Stethoscope, ShieldAlert, CreditCard, Lock } from 'lucide-react';
import { User, UserRole, BloodStock, BloodComponent } from '../../types';
import { SAFE_DONATION_PERIOD_DAYS } from '../../constants';

interface StockModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  allUsers: User[];
  myStock: BloodStock[];
  onConfirm: (
    bankId: string, 
    bloodType: string, 
    units: number, 
    action: 'ADD' | 'REMOVE', 
    relatedPerson?: string, 
    personType?: 'REGISTERED' | 'UNREGISTERED' | 'HOSPITAL',
    relatedUserId?: string,
    component?: BloodComponent
  ) => void;
}

const allBloodTypes = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
const components: BloodComponent[] = ['WHOLE_BLOOD', 'RBC', 'PLATELET', 'PLASMA'];

const StockModal: React.FC<StockModalProps> = ({ isOpen, onClose, currentUser, allUsers, myStock, onConfirm }) => {
  if (!isOpen) return null;

  const [formData, setFormData] = useState<{
    bloodType: string, 
    units: string, 
    action: 'ADD' | 'REMOVE',
    component: BloodComponent,
    personType: 'REGISTERED' | 'UNREGISTERED' | 'HOSPITAL',
    relatedPersonName: string, 
    selectedUserId: string 
  }>({
    bloodType: 'A+', units: '', action: 'ADD', component: 'WHOLE_BLOOD', personType: 'REGISTERED', relatedPersonName: '', selectedUserId: ''
  });

  const [eligibilityWarning, setEligibilityWarning] = useState<string | null>(null);

  const currentStockItem = myStock.find(s => s.bloodType === formData.bloodType && s.component === formData.component);
  const availableUnits = currentStockItem ? currentStockItem.units : 0;
  const enteredUnits = parseInt(formData.units) || 0;
  const isRemoving = formData.action === 'REMOVE';
  const isAdding = formData.action === 'ADD';
  const isInsufficient = isRemoving && enteredUnits > availableUnits;

  const registeredDonors = allUsers.filter(u => u.role === UserRole.DONOR);
  const allRegisteredUsers = allUsers;
  const selectedUser = allUsers.find(u => u.id === formData.selectedUserId);

  useEffect(() => {
    if (isAdding && formData.personType === 'REGISTERED' && selectedUser) {
        setFormData(prev => ({ ...prev, units: '1', component: 'WHOLE_BLOOD' }));
        if (selectedUser.lastDonationDate) {
            const lastDate = new Date(selectedUser.lastDonationDate);
            const today = new Date();
            const diffDays = Math.ceil(Math.abs(today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
            if (diffDays < SAFE_DONATION_PERIOD_DAYS) {
                setEligibilityWarning(`Restricted: Last donation was ${diffDays} days ago. Required: ${SAFE_DONATION_PERIOD_DAYS}d.`);
            } else setEligibilityWarning(null);
        } else setEligibilityWarning(null);
    } else {
      setEligibilityWarning(null);
    }
  }, [formData.selectedUserId, formData.personType, isAdding, selectedUser]);

  const handleUserChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newUserId = e.target.value;
    const user = allUsers.find(u => u.id === newUserId);
    if (user && user.bloodType && isAdding) {
        setFormData(prev => ({ ...prev, selectedUserId: newUserId, bloodType: user.bloodType! }));
    } else {
        setFormData(prev => ({ ...prev, selectedUserId: newUserId }));
    }
  };

  const handleConfirm = () => {
    if (enteredUnits <= 0) return;
    let relatedPerson = formData.personType === 'REGISTERED' ? (selectedUser?.fullName || 'Unknown') : (formData.relatedPersonName || 'External Source');
    onConfirm(currentUser.id, formData.bloodType, enteredUnits, formData.action, relatedPerson, formData.personType, formData.selectedUserId || undefined, formData.component);
  };

  const commonDropdownStyle = {
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7' /%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat', 
      backgroundPosition: 'right 1rem center', 
      backgroundSize: '1.25rem'
  };
  const commonDropdownClass = "w-full bg-white border-2 border-gray-100 text-sm font-black text-gray-700 rounded-2xl py-4 pl-6 pr-12 focus:ring-4 focus:ring-red-100/50 focus:border-red-500 cursor-pointer outline-none appearance-none shadow-sm transition-all hover:border-gray-300 active:scale-[0.99]";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-slide-up flex flex-col max-h-[95vh]">
        
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <div>
            <h3 className="font-black text-gray-900 uppercase tracking-widest text-xs">Inventory Matrix</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter mt-0.5">HUB Session: {currentUser.fullName}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-all active:scale-90">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-8 space-y-6 overflow-y-auto">
           <div className="flex bg-gray-100 p-1.5 rounded-2xl">
             {(['ADD', 'REMOVE'] as const).map(action => (
               <button 
                 key={action} 
                 onClick={() => setFormData(prev => ({ ...prev, action, component: 'WHOLE_BLOOD', units: '' }))} 
                 className={`flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                   formData.action === action 
                   ? (action === 'ADD' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-red-600 text-white shadow-lg') 
                   : 'text-gray-400 hover:bg-gray-200 active:scale-95'
                 }`}
               >
                 {action === 'ADD' ? 'Inventory Deposit' : 'Inventory Issue'}
               </button>
             ))}
           </div>

           <div>
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1 block mb-3">Target Subject</label>
             <div className="flex gap-2 mb-4">
               <button onClick={() => setFormData({...formData, personType: 'REGISTERED'})} className={`flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl border-2 transition-all active:scale-95 ${formData.personType === 'REGISTERED' ? 'bg-gray-900 text-white border-gray-900 shadow-md' : 'border-gray-100 text-gray-400 hover:bg-gray-50'}`}>Authorized Member</button>
               <button onClick={() => setFormData({...formData, personType: formData.action === 'ADD' ? 'UNREGISTERED' : 'HOSPITAL'})} className={`flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl border-2 transition-all active:scale-95 ${formData.personType !== 'REGISTERED' ? 'bg-gray-900 text-white border-gray-900 shadow-md' : 'border-gray-100 text-gray-400 hover:bg-gray-50'}`}>Guest Entity / HUB</button>
             </div>
             
             <div className="animate-fade-in">
               {formData.personType === 'REGISTERED' ? (
                 <div className="space-y-4">
                   <div className="relative">
                    <select value={formData.selectedUserId} onChange={handleUserChange} className={commonDropdownClass} style={commonDropdownStyle}>
                      <option value="">Search Account Identifier...</option>
                      {(formData.action === 'ADD' ? registeredDonors : allRegisteredUsers).map(u => (
                        <option key={u.id} value={u.id}>{u.fullName} [GROUP: {u.bloodType || '?'}]</option>
                      ))}
                    </select>
                   </div>
                   {eligibilityWarning && (
                       <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 flex items-start gap-4">
                         <ShieldAlert className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                         <div>
                           <p className="text-[10px] font-black text-amber-700 uppercase tracking-widest">Safety Lock Active</p>
                           <p className="text-[11px] text-amber-600 font-bold mt-1 leading-relaxed">{eligibilityWarning}</p>
                         </div>
                       </div>
                   )}
                 </div>
               ) : (
                 <div className="space-y-4">
                   <div className="relative group">
                     <input 
                      type="text" 
                      placeholder={formData.action === 'ADD' ? "External Source Identity" : "Hospital / Receiving Entity"} 
                      value={formData.relatedPersonName} 
                      onChange={(e) => setFormData({...formData, relatedPersonName: e.target.value})} 
                      className="w-full p-4 pl-12 bg-gray-50 border-2 border-transparent focus:border-neutral-900 focus:bg-white rounded-2xl outline-none font-bold text-gray-900 text-sm transition-all shadow-sm group-hover:bg-gray-100" 
                     />
                     <Stethoscope className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300 group-focus-within:text-neutral-900 transition-colors" />
                   </div>
                 </div>
               )}
             </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Blood Group</label>
                <select value={formData.bloodType} onChange={(e) => setFormData({...formData, bloodType: e.target.value})} disabled={isAdding && formData.personType === 'REGISTERED'} className={`${commonDropdownClass} mt-2`} style={commonDropdownStyle}>
                   {allBloodTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
             </div>
             <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Component Load</label>
                <select value={formData.component} onChange={(e) => setFormData({...formData, component: e.target.value as BloodComponent})} disabled={isAdding && formData.personType === 'REGISTERED'} className={`${commonDropdownClass} mt-2`} style={commonDropdownStyle}>
                   {components.map(c => <option key={c} value={c}>{c.replace(/_/, ' ')}</option>)}
                </select>
             </div>
           </div>

           <div className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100 relative overflow-hidden group">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Volume Protocol (Units)</label>
              <input 
                type="number" 
                min="1" 
                value={formData.units} 
                onChange={(e) => setFormData({...formData, units: e.target.value})} 
                disabled={isAdding && formData.personType === 'REGISTERED'} 
                className={`w-full mt-2 bg-transparent border-none focus:ring-0 font-black text-6xl text-gray-900 text-center transition-all ${isInsufficient ? 'text-red-600' : ''}`} 
                placeholder="00" 
              />
              <div className="flex justify-between items-center mt-4">
                 <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                   {isAdding && formData.personType === 'REGISTERED' ? 'Standard Load: 1U' : `Grid Available: ${availableUnits}U`}
                 </span>
                 {isInsufficient && (
                   <span className="text-[10px] font-black text-red-500 uppercase tracking-widest animate-pulse flex items-center gap-1">
                     <ShieldAlert className="w-3 h-3" /> Insufficient Load
                   </span>
                 )}
              </div>
           </div>

           {isRemoving && (
             <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 flex items-center gap-3 animate-fade-in">
                <div className="p-2 bg-amber-200 rounded-xl">
                  <CreditCard className="w-4 h-4 text-amber-700" />
                </div>
                <p className="text-[10px] font-black text-amber-700 uppercase leading-tight">
                  Issuance requires secure payment authorization. The QR portal will open upon clicking Authorize.
                </p>
             </div>
           )}
        </div>

        <div className="p-6 border-t border-gray-100 bg-gray-50/50 flex justify-end gap-3">
           <button 
             onClick={onClose} 
             className="px-6 py-4 font-black text-[10px] uppercase text-gray-400 hover:text-gray-900 transition-all active:scale-95"
           >
             Abort Session
           </button>
           <button 
             onClick={handleConfirm} 
             disabled={isInsufficient || enteredUnits <= 0 || !!eligibilityWarning} 
             className={`px-12 py-4 text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] shadow-xl transition-all active:scale-95 flex items-center gap-2 ${ 
               (isInsufficient || enteredUnits <= 0 || !!eligibilityWarning) 
               ? 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none' 
               : (formData.action === 'ADD' ? 'bg-emerald-600 shadow-emerald-200 hover:bg-emerald-700' : 'bg-red-600 shadow-red-200 hover:bg-red-700') 
             }`}
           >
             {formData.action === 'ADD' ? (
               'Authorize Load'
             ) : (
               <>
                 <Lock className="w-3.5 h-3.5" />
                 Pay & Authorize Release
               </>
             )}
           </button>
        </div>
      </div>
    </div>
  );
};

export default StockModal;