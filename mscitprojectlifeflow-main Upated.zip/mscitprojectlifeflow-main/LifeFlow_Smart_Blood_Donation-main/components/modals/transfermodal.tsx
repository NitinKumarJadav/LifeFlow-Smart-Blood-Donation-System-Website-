import React, { useState } from 'react';
import { X, ArrowLeftRight, Building2, Droplet, ShieldAlert } from 'lucide-react';
import { User, UserRole, BloodStock, BloodComponent, BloodTransfer } from '../../types';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  allUsers: User[];
  stock: BloodStock[];
  onConfirm: (transfer: Omit<BloodTransfer, 'id' | 'status' | 'timestamp' | 'sourceBankName' | 'destBankName'>) => void;
}

const allBloodTypes = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
const components: BloodComponent[] = ['WHOLE_BLOOD', 'RBC', 'PLATELET', 'PLASMA'];

const TransferModal: React.FC<TransferModalProps> = ({ isOpen, onClose, currentUser, allUsers, stock, onConfirm }) => {
  if (!isOpen) return null;

  const isAdmin = currentUser.role === UserRole.ADMIN;
  const banks = allUsers.filter(u => u.role === UserRole.BANK);

  const [formData, setFormData] = useState({
    sourceBankId: isAdmin ? '' : currentUser.id,
    destBankId: '',
    bloodType: 'O+',
    component: 'WHOLE_BLOOD' as BloodComponent,
    units: ''
  });

  const sourceBankStock = stock.filter(s => s.bankId === formData.sourceBankId);
  const currentStockItem = sourceBankStock.find(s => s.bloodType === formData.bloodType && s.component === formData.component);
  const availableUnits = currentStockItem ? currentStockItem.units : 0;
  const enteredUnits = parseInt(formData.units) || 0;
  const isInsufficient = enteredUnits > availableUnits;

  const handleConfirm = () => {
    if (enteredUnits <= 0 || isInsufficient || !formData.destBankId || !formData.sourceBankId) return;
    onConfirm({
      sourceBankId: formData.sourceBankId,
      destBankId: formData.destBankId,
      bloodType: formData.bloodType,
      component: formData.component,
      units: enteredUnits,
      initiatedBy: currentUser.role
    });
    onClose();
  };

  const commonDropdownStyle = {
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7' /%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem'
  };
  const commonDropdownClass = "w-full bg-white border-2 border-gray-100 text-sm font-black text-gray-700 rounded-2xl py-3.5 pl-5 pr-12 focus:ring-4 focus:ring-red-100/50 focus:border-red-500 cursor-pointer outline-none appearance-none shadow-sm transition-all hover:border-gray-300 active:scale-[0.99]";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-slide-up">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h3 className="font-black text-gray-900 uppercase tracking-widest text-sm flex items-center gap-2"><ArrowLeftRight className="w-5 h-5" /> Blood Transfer</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors"><X className="w-5 h-5 text-gray-400" /></button>
        </div>
        <div className="p-6 space-y-5">
           {isAdmin && (
             <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Source Hub</label>
                <select value={formData.sourceBankId} onChange={(e) => setFormData({...formData, sourceBankId: e.target.value})} className={commonDropdownClass} style={commonDropdownStyle}>
                   <option value="">Select Origin...</option>
                   {banks.map(b => <option key={b.id} value={b.id}>{b.fullName}</option>)}
                </select>
             </div>
           )}

           <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Destination Hub</label>
              <select value={formData.destBankId} onChange={(e) => setFormData({...formData, destBankId: e.target.value})} className={commonDropdownClass} style={commonDropdownStyle}>
                 <option value="">Select Destination...</option>
                 {banks.filter(b => b.id !== formData.sourceBankId).map(b => <option key={b.id} value={b.id}>{b.fullName}</option>)}
              </select>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div>
                 <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Group</label>
                 <select value={formData.bloodType} onChange={(e) => setFormData({...formData, bloodType: e.target.value})} className={commonDropdownClass} style={commonDropdownStyle}>
                    {allBloodTypes.map(t => <option key={t} value={t}>{t}</option>)}
                 </select>
              </div>
              <div>
                 <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Component</label>
                 <select value={formData.component} onChange={(e) => setFormData({...formData, component: e.target.value as BloodComponent})} className={commonDropdownClass} style={commonDropdownStyle}>
                    {components.map(c => <option key={c} value={c}>{c.replace(/_/, ' ')}</option>)}
                 </select>
              </div>
           </div>

           <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Transfer Load (Units)</label>
              <input type="number" min="1" value={formData.units} onChange={(e) => setFormData({...formData, units: e.target.value})} className={`w-full mt-1 p-4 bg-gray-50 rounded-2xl border-none font-black text-4xl text-gray-900 text-center transition-all ${isInsufficient ? 'bg-red-50 text-red-600 ring-2 ring-red-200' : 'focus:ring-2 focus:ring-red-100'}`} placeholder="0" />
              <div className="flex justify-between items-center mt-3 px-1">
                 <span className="text-[10px] font-black text-gray-400 uppercase">Available: {availableUnits}u</span>
                 {isInsufficient && <span className="text-[10px] font-black text-red-500 uppercase animate-pulse">Insufficient Stock</span>}
              </div>
           </div>
        </div>
        <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
           <button onClick={onClose} className="px-6 py-3 font-black text-[10px] uppercase text-gray-400">Abort</button>
           <button onClick={handleConfirm} disabled={isInsufficient || enteredUnits <= 0 || !formData.destBankId || !formData.sourceBankId} className={`px-10 py-3 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl transition-all active:scale-95 ${ (isInsufficient || enteredUnits <= 0 || !formData.destBankId || !formData.sourceBankId) ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-purple-600 shadow-purple-200' }`}>Authorize Movement</button>
        </div>
      </div>
    </div>
  );
};

export default TransferModal;