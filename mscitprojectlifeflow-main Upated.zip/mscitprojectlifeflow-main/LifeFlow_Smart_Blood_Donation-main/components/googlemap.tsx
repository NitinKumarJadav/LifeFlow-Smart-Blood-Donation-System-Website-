import React, { useEffect, useRef, useState } from 'react';
import { Search, Layers, Map as MapIcon, Eye, EyeOff, Navigation, User as UserIcon } from 'lucide-react';

declare global {
  interface Window {
    L: any;
  }
}

interface MarkerData {
  id: string;
  lat: number;
  lng: number;
  title: string;
  type: 'BANK' | 'DONOR' | 'REQUEST';
  bloodType?: string;
  urgency?: 'URGENT' | 'NORMAL';
  date?: string;
}

interface GoogleMapProps {
  center: { lat: number; lng: number };
  zoom: number;
  markers: MarkerData[];
  onMapClick?: (lat: number, lng: number) => void;
  hideGlobalMarkers?: boolean; 
  showSearch?: boolean;
}

const GoogleMap: React.FC<GoogleMapProps> = ({ center, zoom, markers, onMapClick, hideGlobalMarkers = false, showSearch = true }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const clickHandlerRef = useRef<any>(null);
  
  // UI States
  const [searchQuery, setSearchQuery] = useState('');
  const [isSatellite, setIsSatellite] = useState(false);
  const [showBanks, setShowBanks] = useState(true);
  const [showCamps, setShowCamps] = useState(true);
  const [showDonors, setShowDonors] = useState(true);
  const [isSearching, setIsSearching] = useState(false);

  // Layers
  const streetLayer = useRef<any>(null);
  const satelliteLayer = useRef<any>(null);

  useEffect(() => {
    if (!mapRef.current || !window.L) return;

    if (!mapInstance.current) {
      mapInstance.current = window.L.map(mapRef.current, {
        zoomControl: false 
      }).setView([center.lat, center.lng], zoom);

      streetLayer.current = window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OSM'
      });

      satelliteLayer.current = window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri'
      });

      streetLayer.current.addTo(mapInstance.current);
      window.L.control.zoom({ position: 'bottomright' }).addTo(mapInstance.current);
    } else if (!onMapClick) {
      mapInstance.current.setView([center.lat, center.lng], zoom);
    }
    
    if (isSatellite) {
      if (mapInstance.current.hasLayer(streetLayer.current)) mapInstance.current.removeLayer(streetLayer.current);
      satelliteLayer.current.addTo(mapInstance.current);
    } else {
      if (mapInstance.current.hasLayer(satelliteLayer.current)) mapInstance.current.removeLayer(satelliteLayer.current);
      streetLayer.current.addTo(mapInstance.current);
    }
    
    if (clickHandlerRef.current) {
        mapInstance.current.off('click', clickHandlerRef.current);
    }
    
    if (onMapClick) {
        clickHandlerRef.current = (e: any) => {
            onMapClick(e.latlng.lat, e.latlng.lng);
        };
        mapInstance.current.on('click', clickHandlerRef.current);
        mapRef.current.style.cursor = 'crosshair';
    } else {
        mapRef.current.style.cursor = '';
    }

    markersRef.current.forEach(m => mapInstance.current.removeLayer(m));
    markersRef.current = [];

    markers.forEach(m => {
      // STRICT FILTER: If hideGlobalMarkers is true, ONLY show 'me' or 'new' markers
      if (hideGlobalMarkers && m.id !== 'me' && m.id !== 'new') return;
      
      if (!hideGlobalMarkers) {
        if (!showBanks && m.type === 'BANK') return;
        if (!showCamps && m.type === 'REQUEST') return;
        if (!showDonors && m.type === 'DONOR') return;
      }

      let color = '#ef4444'; 
      if (m.type === 'BANK') color = '#2563eb'; 
      if (m.type === 'DONOR') color = '#10b981'; 
      if (m.type === 'REQUEST') color = '#f59e0b'; 

      const iconHtml = `
        <div style="position: relative; width: 30px; height: 30px;">
          <div style="background-color: ${color};" class="marker-pin"></div>
          <span class="marker-label" style="top: -20px; left: 0; width: 30px; text-align: center; color: ${color}; font-weight: 800; font-size: 14px; text-shadow: 0 0 2px white;">
             ${m.title[0]}
          </span>
        </div>
      `;

      const customIcon = window.L.divIcon({
        className: 'custom-div-icon',
        html: iconHtml,
        iconSize: [30, 42],
        iconAnchor: [15, 42],
        popupAnchor: [0, -35]
      });

      const isRequest = m.type === 'REQUEST';
      const urgencyColor = m.urgency === 'URGENT' ? '#ef4444' : '#2563eb';

      const popupContent = `
        <div style="font-family: 'Inter', sans-serif; min-width: 180px; padding: 8px;">
           <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 800; color: #111827; line-height: 1.2;">${m.title}</h3>
           
           ${isRequest ? `
             <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px;">
               <span style="background: ${urgencyColor}; color: white; padding: 2px 8px; border-radius: 6px; font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.05em;">
                 ${m.urgency}
               </span>
               <span style="background: #f3f4f6; color: #374151; padding: 2px 8px; border-radius: 6px; font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #e5e7eb;">
                 GROUP: ${m.bloodType}
               </span>
             </div>
             <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 12px; color: #6b7280; font-size: 10px; font-weight: 700;">
               <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
               <span>Active: ${m.date}</span>
             </div>
           ` : `
             <p style="margin: 0 0 12px 0; font-size: 11px; color: #6b7280; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;">${m.type}</p>
           `}
           
           ${!hideGlobalMarkers ? `
              <a href="https://www.google.com/maps/dir/?api=1&destination=${m.lat},${m.lng}" 
                 target="_blank" 
                 style="display: block; text-align: center; background-color: #111827; color: white; padding: 10px 12px; border-radius: 12px; text-decoration: none; font-size: 11px; font-weight: 800; transition: all 0.2s; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); margin-top: 4px;">
                NAVIGATE GRID
              </a>
           ` : ''}
        </div>
      `;

      const marker = window.L.marker([m.lat, m.lng], { icon: customIcon })
        .addTo(mapInstance.current)
        .bindPopup(popupContent);

      markersRef.current.push(marker);
    });

    setTimeout(() => {
        mapInstance.current?.invalidateSize();
    }, 200);

  }, [center, zoom, markers, onMapClick, isSatellite, showBanks, showCamps, showDonors, hideGlobalMarkers]);

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim() || isSearching) return;
    
    setIsSearching(true);
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      if (data && data.length > 0) {
        const { lat, lon } = data[0];
        mapInstance.current.setView([parseFloat(lat), parseFloat(lon)], 14);
      }
    } catch (err) {
      console.error("Search failed", err);
    } finally {
      setIsSearching(false);
    }
  };

  if (typeof window !== 'undefined' && !window.L) {
      return <div className="w-full h-full bg-gray-50 flex items-center justify-center text-gray-400 font-bold animate-pulse">ATLAS SYNC...</div>;
  }

  return (
    <div className="relative w-full h-full group isolate">
      {/* Container-level Z-index fixes: Controls use z-10 to stay below sticky header (z-30) */}
      <div className="absolute top-3 left-3 right-3 z-10 pointer-events-none flex flex-col gap-2">
         {showSearch && (
           <form 
             onSubmit={handleSearch}
             className="pointer-events-auto w-full bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-white/50 p-1 flex items-center gap-1 max-w-sm group"
           >
             <div className="pl-3">
               <Search className={`w-4 h-4 ${isSearching ? 'text-blue-500 animate-spin' : 'text-gray-400 group-focus-within:text-red-500 transition-colors'}`} />
             </div>
             <input 
               type="text" 
               placeholder="Search location..." 
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               className="flex-1 bg-transparent border-none focus:ring-0 text-xs font-bold text-gray-900 placeholder:text-gray-400 py-1.5"
             />
             <button 
               type="submit"
               disabled={isSearching}
               className="bg-gray-900 text-white px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-black transition-all active:scale-95 disabled:opacity-50"
             >
               Go
             </button>
           </form>
         )}

         {!hideGlobalMarkers && (
            <div className="pointer-events-auto flex gap-2">
                <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-xl border border-white p-1 flex items-center gap-1">
                <button onClick={() => setIsSatellite(!isSatellite)} className={`p-2 rounded-xl transition-all ${isSatellite ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-100'}`}><Layers className="w-4 h-4" /></button>
                <div className="w-[1px] h-6 bg-gray-200 mx-1"></div>
                
                <button onClick={() => setShowBanks(!showBanks)} className={`p-2 rounded-xl transition-all flex items-center gap-2 px-3 ${showBanks ? 'bg-blue-50 text-blue-700 border border-blue-100 font-black' : 'text-gray-400 hover:bg-gray-100'}`}>
                    {showBanks ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    <span className="text-[10px] uppercase">Banks</span>
                </button>
                
                <button onClick={() => setShowDonors(!showDonors)} className={`p-2 rounded-xl transition-all flex items-center gap-2 px-3 ${showDonors ? 'bg-green-50 text-green-700 border border-green-100 font-black' : 'text-gray-400 hover:bg-gray-100'}`}>
                    {showDonors ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    <span className="text-[10px] uppercase">Donors</span>
                </button>

                <button onClick={() => setShowCamps(!showCamps)} className={`p-2 rounded-xl transition-all flex items-center gap-2 px-3 ${showCamps ? 'bg-orange-50 text-orange-700 border border-orange-100 font-black' : 'text-gray-400 hover:bg-gray-100'}`}>
                    {showCamps ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    <span className="text-[10px] uppercase">Camps</span>
                </button>
                </div>
            </div>
         )}
      </div>

      <div ref={mapRef} className="w-full h-full z-0 relative" style={{ minHeight: '100%' }} />
      
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
         <div className="bg-gray-900/80 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 text-[9px] font-black text-white uppercase tracking-widest flex items-center gap-2 shadow-lg">
            <Navigation className="w-2.5 h-2.5 text-blue-400 fill-current" />
            {hideGlobalMarkers ? 'Picker Active' : 'Live Network'}
         </div>
      </div>
    </div>
  );
};

export default GoogleMap;