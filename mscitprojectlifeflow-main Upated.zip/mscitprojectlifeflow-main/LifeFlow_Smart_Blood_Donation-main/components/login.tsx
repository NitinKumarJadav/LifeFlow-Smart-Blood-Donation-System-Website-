import React, { useState } from 'react';
import { Droplet, Lock, User, ArrowRight, ShieldCheck, Heart, Building2, ChevronLeft, Mail } from 'lucide-react';
import { DEFAULT_PASSWORD } from '../constants';

interface LoginProps {
  onLogin: (username: string) => void;
  // Support both sync and async return for flexibility
  onForgotPassword: (username: string) => boolean | Promise<boolean>;
}

const Login: React.FC<LoginProps> = ({ onLogin, onForgotPassword }) => {
  const [mode, setMode] = useState<'login' | 'forgot'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [resetUsername, setResetUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      onLogin(username);
    }
  };

  // Changed to async to handle potential promise from onForgotPassword
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (resetUsername) {
      const result = onForgotPassword(resetUsername);
      const success = result instanceof Promise ? await result : result;
      if (success) {
        setMode('login');
        setResetUsername('');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-5xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row animate-fade-in border border-white/20">
        
        {/* Left Side - Brand (Static) */}
        <div className="md:w-1/2 bg-red-600 p-12 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
             <div className="absolute top-[-50px] right-[-50px] w-64 h-64 rounded-full bg-white blur-3xl"></div>
             <div className="absolute bottom-[-50px] left-[-50px] w-64 h-64 rounded-full bg-black blur-3xl"></div>
          </div>

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm transition-transform hover:rotate-12 cursor-pointer">
                <Droplet className="w-8 h-8 text-white fill-current" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight">LifeFlow</h1>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-extrabold leading-tight mb-6 animate-slide-up">
              Every Drop <br/> Saves a Life.
            </h2>
            <p className="text-red-100 text-lg leading-relaxed max-w-md">
              Connect with donors, manage blood inventory, and fulfill urgent requests in real-time with our smart platform.
            </p>
          </div>

          <div className="relative z-10 mt-12 grid grid-cols-3 gap-4 text-center">
             <div className="bg-red-700/50 p-4 rounded-2xl backdrop-blur-sm border border-red-500/30 hover:bg-red-700 transition-colors cursor-default">
                <Heart className="w-6 h-6 mx-auto mb-2 text-red-200" />
                <span className="text-xs font-bold text-red-100">Donor</span>
             </div>
             <div className="bg-red-700/50 p-4 rounded-2xl backdrop-blur-sm border border-red-500/30 hover:bg-red-700 transition-colors cursor-default">
                <Building2 className="w-6 h-6 mx-auto mb-2 text-red-200" />
                <span className="text-xs font-bold text-red-100">Bank</span>
             </div>
             <div className="bg-red-700/50 p-4 rounded-2xl backdrop-blur-sm border border-red-500/30 hover:bg-red-700 transition-colors cursor-default">
                <ShieldCheck className="w-6 h-6 mx-auto mb-2 text-red-200" />
                <span className="text-xs font-bold text-red-100">Admin</span>
             </div>
          </div>
        </div>

        {/* Right Side - Forms with Transitions */}
        <div className="md:w-1/2 p-8 md:p-12 bg-white flex flex-col justify-center relative overflow-hidden">
          
          {/* Login Form */}
          <div className={`max-w-sm mx-auto w-full space-y-8 transition-all duration-500 transform ${mode === 'login' ? 'translate-x-0 opacity-100' : '-translate-x-full opacity-0 absolute pointer-events-none'}`}>
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold text-gray-900 tracking-tight">Access Secure Grid</h3>
              <p className="text-gray-500 mt-2 font-medium">Log in to your operational dashboard.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="relative group">
                  <User className="absolute left-4 top-4 w-5 h-5 text-gray-400 group-focus-within:text-red-500 transition-colors" />
                  <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 rounded-2xl border-2 border-transparent focus:border-red-500 focus:bg-white outline-none transition-all font-bold text-gray-900 shadow-sm"
                  />
                </div>
                <div className="relative group">
                  <Lock className="absolute left-4 top-4 w-5 h-5 text-gray-400 group-focus-within:text-red-500 transition-colors" />
                  <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 rounded-2xl border-2 border-transparent focus:border-red-500 focus:bg-white outline-none transition-all font-bold text-gray-900 shadow-sm"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end text-sm">
                <button 
                  type="button" 
                  onClick={() => setMode('forgot')}
                  className="font-black text-red-600 hover:text-red-700 uppercase text-[11px] tracking-widest"
                >
                  Forgot Password?
                </button>
              </div>

              <button 
                type="submit"
                className="w-full bg-gray-900 text-white py-4 rounded-2xl font-black uppercase text-sm tracking-widest hover:bg-black transition-all active:scale-95 shadow-2xl shadow-gray-200 flex items-center justify-center gap-2 group"
              >
                Engage <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
            
            <div className="pt-8 border-t border-gray-100">
               <p className="text-center text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Diagnostic Quick-Login</p>
               <div className="grid grid-cols-3 gap-2">
                 <button onClick={() => {setUsername('admin'); setPassword('123');}} className="text-[10px] py-2.5 bg-gray-50 hover:bg-gray-100 rounded-xl text-gray-600 font-black uppercase tracking-tighter transition-all hover:shadow-inner">
                   Admin
                 </button>
                 <button onClick={() => {setUsername('redcross_ny'); setPassword('123');}} className="text-[10px] py-2.5 bg-gray-50 hover:bg-gray-100 rounded-xl text-gray-600 font-black uppercase tracking-tighter transition-all hover:shadow-inner">
                   Bank
                 </button>
                 <button onClick={() => {setUsername('johndoe'); setPassword('123');}} className="text-[10px] py-2.5 bg-gray-50 hover:bg-gray-100 rounded-xl text-gray-600 font-black uppercase tracking-tighter transition-all hover:shadow-inner">
                   Donor
                 </button>
               </div>
            </div>
          </div>

          {/* Forgot Password Form */}
          <div className={`max-w-sm mx-auto w-full space-y-8 transition-all duration-500 transform ${mode === 'forgot' ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0 absolute pointer-events-none'}`}>
            <button 
              onClick={() => setMode('login')}
              className="flex items-center gap-2 text-gray-400 hover:text-gray-900 transition-colors mb-4 group"
            >
              <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              <span className="font-black text-[10px] uppercase tracking-widest">Back to Login</span>
            </button>

            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold text-gray-900 tracking-tight">Security Recovery</h3>
              <p className="text-gray-500 mt-2 font-medium leading-relaxed">
                Provide your identity handle to reset your system access credentials to default.
              </p>
            </div>

            <form onSubmit={handleResetSubmit} className="space-y-6">
              <div className="relative group">
                <Mail className="absolute left-4 top-4 w-5 h-5 text-gray-400 group-focus-within:text-red-500 transition-colors" />
                <input
                  type="text"
                  placeholder="Enter Username"
                  value={resetUsername}
                  onChange={(e) => setResetUsername(e.target.value)}
                  required
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 rounded-2xl border-2 border-transparent focus:border-red-500 focus:bg-white outline-none transition-all font-bold text-gray-900 shadow-sm"
                />
              </div>

              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                <p className="text-blue-700 text-[11px] font-bold leading-relaxed">
                  <span className="font-black uppercase block mb-1">Notice:</span>
                  Password will be reverted to the system default: <code className="bg-blue-100 px-1 rounded text-blue-900 font-mono">{DEFAULT_PASSWORD}</code>
                </p>
              </div>

              <button 
                type="submit"
                className="w-full bg-red-600 text-white py-4 rounded-2xl font-black uppercase text-sm tracking-widest hover:bg-red-700 transition-all active:scale-95 shadow-xl shadow-red-100 flex items-center justify-center gap-2"
              >
                Reset Credentials
              </button>
            </form>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Login;