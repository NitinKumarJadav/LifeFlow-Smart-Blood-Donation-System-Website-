import React, { useState } from 'react';
import { User, BloodStock, DonationRequest, AuditLog, UserRole, BloodComponent, BloodTransfer } from '../../types';
import { Users, Droplet, Building2, Plus, ListFilter as Filter, CircleAlert as AlertCircle, CreditCard as Edit2, Trash2, Lock, History, ChartBar as BarChart3, ChartPie as PieChart, TrendingUp, Activity, ShieldAlert, ArrowUpRight, Lightbulb, CircleCheck as CheckCircle, ShieldCheck, User as UserIcon, Send, ArrowLeftRight, Check, X, Navigation, Zap, Loader, BellRing, Search } from 'lucide-react';
import ConfirmModal from '../modals/confirmmodal';
import Tooltip from '../ui/tooltip';
import GoogleMap from '../googlemap';
import EmergencyMatchModal from '../modals/emergencymatchmodal';
import { matchEmergencyDonorsLocal } from './emergencyMatchingService';

interface AdminDashboardProps {
  allUsers: User[];
  stock: BloodStock[];
  requests: DonationRequest[];
  transfers: BloodTransfer[];
  logs?: AuditLog[];
  onOpenUserModal: (user?: User) => void;
  onDeleteUser: (id: string) => void;
  onResetPassword: (id: string) => void;
  onDeleteRequest: (id: string) => void;
  onOpenRequestModal?: (initialData?: Partial<DonationRequest>) => void;
  onOpenTransferModal?: () => void;
  onApproveTransfer: (id: string) => void;
  onRejectTransfer: (id: string) => void;
  onNotifyDonor?: (requestId: string, donorId: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  allUsers, stock, requests, transfers, logs = [], onOpenUserModal, onDeleteUser, onResetPassword, onDeleteRequest, onOpenRequestModal, onOpenTransferModal, onApproveTransfer, onRejectTransfer, onNotifyDonor
}) => {
  const [tab, setTab] = useState<'analytics' | 'users' | 'inventory' | 'transfers' | 'requests' | 'map' | 'history'>('analytics');
  const [stockFilter, setStockFilter] = useState<string>('ALL');
  const [bloodTypeFilter, setBloodTypeFilter] = useState<string>('ALL');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'STOCK' | 'USER' | 'REQUEST' | 'TRANSFER'>('ALL');
  const [emergencyMatchModal, setEmergencyMatchModal] = useState<{ isOpen: boolean; requestId?: string; matchedDonors: any[]; bloodType: string; urgency: string }>({ isOpen: false, matchedDonors: [], bloodType: '', urgency: '' });
  const [matchingLoading, setMatchingLoading] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    isDanger: boolean;
  }>({
    isOpen: false, title: '', message: '', onConfirm: () => {}, isDanger: false
  });

  const banks = allUsers.filter(u => u.role === UserRole.BANK);
  const donors = allUsers.filter(u => u.role === UserRole.DONOR);
  const allBloodTypes = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
  const components: BloodComponent[] = ['WHOLE_BLOOD', 'RBC', 'PLATELET', 'PLASMA'];

  const calculateDetailedStock = (filterBankId: string) => {
    const data: Record<string, Record<BloodComponent, number>> = {};
    allBloodTypes.forEach(t => { data[t] = { 'WHOLE_BLOOD': 0, 'RBC': 0, 'PLATELET': 0, 'PLASMA': 0 }; });
    stock.forEach(s => {
      if (filterBankId === 'ALL' || s.bankId === filterBankId) {
        if (data[s.bloodType]) data[s.bloodType][s.component] += s.units;
      }
    });
    return data;
  };

  const detailedStock = calculateDetailedStock(stockFilter);

  const filteredLogs = (logs || []).map(l => ({
    ...l,
    category: l.action.includes('STOCK') || l.action.includes('COMPONENT') ? 'STOCK' as const : l.action.includes('USER') ? 'USER' as const : l.action.includes('TRANSFER') ? 'TRANSFER' as const : 'REQUEST' as const
  })).filter(l => {
     if (historyFilter === 'ALL') return true;
     return l.category === historyFilter;
  }).sort((a, b) => b.timestamp - a.timestamp);

  const stockByType = allBloodTypes.map(type => {
    const total = stock.filter(s => s.bloodType === type).reduce((acc, curr) => acc + curr.units, 0);
    return { type, count: total };
  });
  const totalStock = stockByType.reduce((acc, curr) => acc + curr.count, 0);
  const urgentRequestsCount = requests.filter(r => r.urgency === 'URGENT').length;
  
  const lowStockTypes = stockByType.filter(s => s.count < 15).map(s => s.type);
  
  const handleInitiateDrive = () => onOpenRequestModal?.({ urgency: 'URGENT', bloodType: lowStockTypes[0] || 'O+', location: 'City General Area' });

  const getInsights = () => {
    const items = [];
    if (lowStockTypes.length > 0) items.push({ id: 'i1', type: 'CRITICAL', title: 'Supply Deficit', description: `Alert: Low stock for types: ${lowStockTypes.join(', ')}.`, action: 'Initiate Drive', onAction: handleInitiateDrive, icon: ShieldAlert, colorStyle: 'bg-red-50 text-red-700 border-red-100', btnStyle: 'bg-red-600 text-white hover:bg-red-700' });
    if (transfers.filter(t=>t.status === 'PENDING').length > 0) items.push({ id: 'i2', type: 'ACTION', title: 'Pending Transfers', description: `${transfers.filter(t=>t.status === 'PENDING').length} movements awaiting authorization.`, action: 'Review Pipeline', onAction: () => setTab('transfers'), icon: ArrowLeftRight, colorStyle: 'bg-yellow-50 text-yellow-700 border-yellow-100', btnStyle: 'bg-yellow-600 text-white hover:bg-yellow-700' });
    if (urgentRequestsCount > 0) items.push({ id: 'i3', type: 'PRIORITY', title: 'Patient Demand', description: `${urgentRequestsCount} active critical requests. System allocation pending.`, action: 'View Queues', onAction: () => setTab('requests'), icon: Activity, colorStyle: 'bg-orange-50 text-orange-700 border-orange-100', btnStyle: 'bg-orange-600 text-white hover:bg-orange-700' });
    return items;
  };

  const insights = getInsights();

  const handleEmergencyMatch = async (request: DonationRequest) => {
    setMatchingLoading(request.id);
    await new Promise(r => setTimeout(r, 1000));
    const result = matchEmergencyDonorsLocal(request, allUsers);
    setEmergencyMatchModal({
      isOpen: true,
      requestId: request.id,
      matchedDonors: result.matchedDonors,
      bloodType: request.bloodType,
      urgency: request.urgency,
    });
    setMatchingLoading(null);
  };

  const handleNotifyDonor = (donorId: string) => {
    if (emergencyMatchModal.requestId) {
      onNotifyDonor?.(emergencyMatchModal.requestId, donorId);
    }
  };

  const handleNotifyAllMatched = (request: DonationRequest) => {
    const pledges = request.pledgedDonorIds || [];
    if (pledges.length === 0) return;

    pledges.forEach(donorId => {
      onNotifyDonor?.(request.id, donorId);
    });
  };

  const promptDeleteUser = (user: User) => {
    setConfirmModal({
        isOpen: true, title: 'Archive User?', message: `Are you sure you want to archive ${user.fullName}? This will restrict their access.`,
        isDanger: true, onConfirm: () => onDeleteUser(user.id)
    });
  };

  const promptDeleteRequest = (requestId: string, bankName: string) => {
    setConfirmModal({
        isOpen: true, title: 'Abort Request?', message: `Are you sure you want to abort the donation request from ${bankName}?`,
        isDanger: true, onConfirm: () => onDeleteRequest(requestId)
    });
  };

  const commonDropdownStyle = {
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7' /%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat', backgroundPosition: 'right 0.75rem center', backgroundSize: '1.25rem'
  };
  const commonDropdownClass = "bg-white border-2 border-gray-100 text-sm font-black text-gray-700 rounded-2xl py-3 pl-5 pr-10 focus:ring-4 focus:ring-red-100/50 focus:border-red-500 cursor-pointer outline-none appearance-none shadow-sm transition-all hover:border-gray-300 active:scale-[0.99]";

  const bankMarkers = banks.filter(u => u.coordinates).map(u => ({ id: u.id, lat: u.coordinates!.lat, lng: u.coordinates!.lng, title: u.fullName, type: 'BANK' as const }));
  const donorMarkers = donors.filter(u => u.coordinates).map(u => ({ id: u.id, lat: u.coordinates!.lat, lng: u.coordinates!.lng, title: u.fullName, type: 'DONOR' as const }));
  const requestMarkers = requests.filter(r => r.status === 'OPEN' && r.coordinates).map(r => ({ 
    id: r.id, 
    lat: r.coordinates!.lat, 
    lng: r.coordinates!.lng, 
    title: r.bankName, 
    type: 'REQUEST' as const,
    bloodType: r.bloodType,
    urgency: r.urgency,
    date: r.date
  }));
  const adminMapMarkers = [...bankMarkers, ...donorMarkers, ...requestMarkers];
  const mapCenter = { lat: 40.7128, lng: -74.0060 };

  const filteredUsers = allUsers.filter(u => 
    u.fullName.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
    u.username.toLowerCase().includes(userSearchQuery.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 animate-fade-in relative">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-2">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 tracking-tight">System Oversight</h2>
            <p className="text-gray-500 font-medium mt-1">Intelligence-led resource optimization</p>
          </div>
          <div className="flex bg-white p-1 rounded-xl border border-gray-200 shadow-sm overflow-x-auto">
            {(['analytics', 'users', 'inventory', 'transfers', 'requests', 'map', 'history'] as const).map(t => (
              <button key={t} onClick={() => setTab(t)} className={`px-5 py-2 rounded-lg text-sm font-bold transition-all ${tab === t ? 'bg-gray-900 text-white shadow-md' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'} capitalize flex items-center gap-2 whitespace-nowrap`}>
                {t}
              </button>
            ))}
          </div>
        </div>

        {tab === 'analytics' && (
          <div className="animate-slide-up space-y-6">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-between items-start mb-4"><div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><Users className="w-6 h-6" /></div><span className="bg-green-100 text-green-700 text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter">Verified</span></div>
                <p className="text-4xl font-black text-gray-900 mb-1">{allUsers.length}</p>
                <p className="text-gray-400 font-bold text-[10px] uppercase tracking-widest">Global Members</p>
              </div>
              <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all">
                 <div className="flex justify-between items-start mb-4"><div className="p-3 bg-red-50 text-red-600 rounded-2xl"><Droplet className="w-6 h-6" /></div><span className="bg-red-100 text-red-700 text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter">Inventory</span></div>
                <p className="text-4xl font-black text-gray-900 mb-1">{totalStock}</p>
                <p className="text-gray-400 font-bold text-[10px] uppercase tracking-widest">Total Grid Units</p>
              </div>
              <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all">
                 <div className="flex justify-between items-start mb-4"><div className="p-3 bg-purple-50 text-purple-600 rounded-2xl"><Building2 className="w-6 h-6" /></div><span className="bg-gray-100 text-gray-700 text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter">Nodes</span></div>
                <p className="text-4xl font-black text-gray-900 mb-1">{banks.length}</p>
                <p className="text-gray-400 font-bold text-[10px] uppercase tracking-widest">Active Hub Nodes</p>
              </div>
            </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="col-span-full mb-1"><h4 className="text-lg font-black text-gray-900 flex items-center gap-2 uppercase tracking-tighter"><Lightbulb className="w-5 h-5 text-yellow-500" /> Strategic Matrix</h4></div>
                {insights.map(item => (
                   <div key={item.id} className={`p-5 rounded-[1.5rem] border flex flex-col justify-between ${item.colorStyle}`}>
                      <div><div className="flex justify-between items-start mb-3"><div className="p-2 bg-white/60 rounded-xl backdrop-blur-sm"><item.icon className="w-5 h-5" /></div><span className="text-[10px] font-black bg-white/60 px-2 py-1 rounded-md uppercase tracking-wider">{item.type}</span></div><h5 className="font-black text-base leading-tight mb-2 uppercase tracking-tighter">{item.title}</h5><p className="text-[11px] font-medium opacity-80 mb-4 leading-relaxed">{item.description}</p></div>
                      <button onClick={item.onAction} className={`w-full py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-sm ${item.btnStyle}`}>{item.action} <ArrowUpRight className="w-3 h-3" /></button>
                   </div>
                ))}
             </div>
          </div>
        )}

        {tab === 'users' && (
          <div className="animate-slide-up space-y-4">
             <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="relative flex-1 max-w-md group w-full">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-red-500 transition-colors" />
                    <input 
                      type="text" 
                      placeholder="Search accounts by name or handle..." 
                      value={userSearchQuery}
                      onChange={(e) => setUserSearchQuery(e.target.value)}
                      className="w-full pl-11 pr-4 py-2.5 bg-white border border-gray-100 rounded-xl focus:ring-2 focus:ring-red-100 focus:border-red-200 text-sm font-medium text-gray-900 placeholder:text-gray-400 shadow-sm transition-all"
                    />
                </div>
                <button onClick={() => onOpenUserModal()} className="flex items-center gap-2 bg-gray-900 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-800 transition-all shadow-lg active:scale-95 whitespace-nowrap"><Plus className="w-4 h-4" /> Add User</button>
             </div>
             <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
                <table className="w-full text-left min-w-[600px]">
                  <thead className="bg-gray-50 border-b border-gray-100"><tr><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">User Identity</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Role</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Utility</th></tr></thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredUsers.map(u => (
                      <tr key={u.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-gray-200 overflow-hidden">{u.avatarUrl ? <img src={u.avatarUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-gray-100 text-gray-400"><UserIcon className="w-1/2 h-1/2" /></div>}</div><div><p className="font-bold text-gray-900 text-sm leading-none">{u.fullName}</p><p className="text-[10px] text-gray-400 font-bold mt-1 uppercase">@{u.username}</p></div></div></td>
                        <td className="px-6 py-4"><span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${u.role === UserRole.ADMIN ? 'bg-purple-100 text-purple-700' : u.role === UserRole.BANK ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>{u.role.replace('_', ' ')}</span></td>
                        <td className="px-6 py-4">
                           <div className="flex justify-end gap-1.5 flex-nowrap whitespace-nowrap">
                             <Tooltip content="Security Reset"><button onClick={() => onResetPassword(u.id)} className="p-2 text-gray-400 hover:text-orange-600 rounded-xl transition-all"><Lock className="w-4 h-4" /></button></Tooltip>
                             <Tooltip content="Modify"><button onClick={() => onOpenUserModal(u)} className="p-2 text-gray-400 hover:text-blue-600 rounded-xl transition-all"><Edit2 className="w-4 h-4" /></button></Tooltip>
                             <Tooltip content="Archive"><button onClick={() => promptDeleteUser(u)} className="p-2 text-gray-400 hover:text-red-600 rounded-xl transition-all"><Trash2 className="w-4 h-4" /></button></Tooltip>
                           </div>
                        </td>
                      </tr>
                    ))}
                    {filteredUsers.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-6 py-12 text-center text-gray-400 font-bold uppercase text-xs tracking-widest">
                           No accounts match search criteria
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
             </div>
          </div>
        )}

        {tab === 'inventory' && (
          <div className="animate-slide-up space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-center bg-white p-4 rounded-2xl border border-gray-100 shadow-sm gap-4">
              <div className="flex items-center gap-3 text-gray-800 text-sm font-black uppercase tracking-tighter">
                <div className="p-2 bg-yellow-50 text-yellow-600 rounded-lg"><Filter className="w-4 h-4" /></div>
                Grid Logistics
              </div>
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                <select 
                  value={stockFilter} 
                  onChange={(e) => setStockFilter(e.target.value)} 
                  className={commonDropdownClass} 
                  style={commonDropdownStyle}
                >
                  <option value="ALL">Entire Global Grid</option>
                  {banks.map(b => (<option key={b.id} value={b.id}>{b.fullName}</option>))}
                </select>
                <select 
                  value={bloodTypeFilter} 
                  onChange={(e) => setBloodTypeFilter(e.target.value)} 
                  className={commonDropdownClass} 
                  style={commonDropdownStyle}
                >
                  <option value="ALL">All Blood Types</option>
                  {allBloodTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
               {allBloodTypes
                 .filter(type => bloodTypeFilter === 'ALL' || type === bloodTypeFilter)
                 .map(type => {
                  const typeData = detailedStock[type];
                  const totalForType = components.reduce((acc, c) => acc + typeData[c], 0);
                  return (
                    <div key={type} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col hover:shadow-xl transition-all group overflow-hidden relative">
                       <div className="absolute top-0 right-0 bg-red-50 px-4 py-2 rounded-bl-3xl font-black text-red-600 text-2xl border-l border-b border-red-100">{type}</div>
                       <span className="text-[10px] font-black text-gray-400 uppercase mb-4 tracking-widest">Supply Matrix</span>
                       <div className="space-y-2 mb-4">{components.map(comp => (<div key={comp} className="flex justify-between items-center bg-gray-50/50 p-2 rounded-xl border border-gray-100"><span className="text-[9px] font-black text-gray-400 uppercase tracking-tighter">{comp.replace(/_/, ' ')}</span><span className={`font-black text-sm ${typeData[comp] > 0 ? 'text-gray-900' : 'text-gray-300'}`}>{typeData[comp]}</span></div>))}</div>
                       <div className="mt-auto pt-4 border-t border-gray-100 flex justify-between items-end"><div><p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Total Payload</p><p className="text-3xl font-black text-gray-900 leading-none">{totalForType}u</p></div><div className={`w-10 h-10 rounded-2xl flex items-center justify-center border-2 transition-all ${totalForType < 10 ? 'border-red-100 text-red-600 bg-red-50' : 'border-green-100 text-green-600 bg-green-50'}`}><Activity className="w-5 h-5" /></div></div>
                    </div>
                  )
               })}
            </div>
          </div>
        )}

        {tab === 'transfers' && (
          <div className="animate-slide-up space-y-6">
             <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm">
                <div><h3 className="text-xl font-bold text-gray-900">Transfer Authorization</h3><p className="text-gray-500 text-sm font-medium">Manage hub-to-hub movement requests.</p></div>
                <button onClick={onOpenTransferModal} className="bg-gray-900 text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 flex items-center gap-2 hover:bg-black transition-all"><ArrowLeftRight className="w-4 h-4" /> Direct Transfer</button>
             </div>
             <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
                <table className="w-full text-left min-w-[800px]">
                   <thead className="bg-gray-50 border-b border-gray-100">
                      <tr><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Route</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Payload</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Status</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Actions</th></tr>
                   </thead>
                   <tbody className="divide-y divide-gray-50">
                      {transfers.map(t => (
                        <tr key={t.id} className="hover:bg-gray-50/50 transition-colors">
                           <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                 <div className="p-2 bg-purple-50 text-purple-600 rounded-lg"><ArrowLeftRight className="w-4 h-4" /></div>
                                 <div><p className="text-sm font-bold text-gray-900 leading-tight">{t.sourceBankName} → {t.destBankName}</p><p className="text-[10px] text-gray-400 font-bold uppercase">{t.initiatedBy} INITIATED</p></div>
                              </div>
                           </td>
                           <td className="px-6 py-4 font-black text-gray-700">{t.units}u {t.bloodType} {t.component.replace('_', ' ')}</td>
                           <td className="px-6 py-4"><span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border ${t.status === 'APPROVED' ? 'bg-green-50 text-green-700 border-green-100' : t.status === 'REJECTED' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-orange-50 text-orange-700 border-orange-100'}`}>{t.status}</span></td>
                           <td className="px-6 py-4">
                              <div className="flex justify-end gap-3">
                                 {t.status === 'PENDING' && (
                                   <>
                                      <button 
                                        onClick={() => onApproveTransfer(t.id)} 
                                        className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-100 hover:bg-emerald-700 active:scale-95 transition-all flex items-center gap-1.5"
                                      >
                                        <Check className="w-3.5 h-3.5" /> Approve
                                      </button>
                                      <button 
                                        onClick={() => onRejectTransfer(t.id)} 
                                        className="px-4 py-2 border-2 border-red-100 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-50 active:scale-95 transition-all flex items-center gap-1.5"
                                      >
                                        <X className="w-3.5 h-3.5" /> Reject
                                      </button>
                                   </>
                                 )}
                              </div>
                           </td>
                        </tr>
                      ))}
                      {transfers.length === 0 && <tr><td colSpan={4} className="p-12 text-center text-gray-400 font-bold uppercase text-xs tracking-[0.2em]">Pipeline Clear • No Pending Movements</td></tr>}
                   </tbody>
                </table>
             </div>
          </div>
        )}

        {tab === 'requests' && (
           <div className="animate-slide-up space-y-6">
              <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
                <table className="w-full text-left min-w-[600px]">
                  <thead className="bg-gray-50 border-b border-gray-100"><tr><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Origin</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Requirement</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Utility</th></tr></thead>
                  <tbody className="divide-y divide-gray-50">
                    {requests.map(r => {
                      const pledgeCount = r.pledgedDonorIds?.length || 0;
                      return (
                      <tr key={r.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-bold text-gray-900">{r.bankName}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <span className={`px-3 py-1 rounded-lg font-black text-xs shadow-sm ${r.urgency === 'URGENT' ? 'bg-red-500 text-white' : 'bg-blue-600 text-white'}`}>{r.bloodType}</span>
                            <div><p className="text-[10px] font-black text-gray-800 uppercase">{r.urgency}</p></div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button 
                              onClick={() => handleNotifyAllMatched(r)}
                              disabled={pledgeCount === 0}
                              className={`font-black text-[10px] uppercase px-4 py-2 rounded-xl transition-all active:scale-95 flex items-center gap-2 ${pledgeCount === 0 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'text-amber-600 hover:text-white border-2 border-amber-100 hover:bg-amber-600'}`}
                            >
                              <BellRing className="w-3.5 h-3.5" />
                              Notify All ({pledgeCount})
                            </button>
                            <button onClick={() => handleEmergencyMatch(r)} disabled={matchingLoading === r.id} className={`font-black text-[10px] uppercase px-4 py-2 rounded-xl transition-all active:scale-95 flex items-center gap-2 ${matchingLoading === r.id ? 'bg-yellow-100 text-yellow-700 cursor-wait' : 'text-yellow-600 hover:text-white border-2 border-yellow-100 hover:bg-yellow-600'}`}><Zap className="w-3 h-3" />{matchingLoading === r.id ? 'Matching' : 'Match'}</button>
                            <button onClick={() => promptDeleteRequest(r.id, r.bankName)} className="text-red-500 hover:text-white font-black text-[10px] uppercase border-2 border-red-100 hover:bg-red-600 px-4 py-2 rounded-xl transition-all active:scale-95">Abort</button>
                          </div>
                        </td>
                      </tr>
                    )})}
                  </tbody>
                </table>
              </div>
           </div>
        )}

        {tab === 'map' && (
          <div className="animate-slide-up space-y-4">
             <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm h-[600px]">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2"><Navigation className="w-5 h-5 text-blue-600" /> Global Network Topology</h3>
                <div className="h-[500px] rounded-[1.5rem] overflow-hidden border border-gray-200">
                  <GoogleMap center={mapCenter} zoom={10} markers={adminMapMarkers} />
                </div>
             </div>
          </div>
        )}

        {tab === 'history' && (
          <div className="animate-slide-up space-y-6">
            <div className="flex flex-col sm:flex-row items-center gap-4 bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                 <div className="flex items-center gap-3"><div className="p-2 bg-gray-100 rounded-lg text-gray-600"><History className="w-5 h-5" /></div><h3 className="font-black text-gray-900 tracking-tight uppercase text-sm">Audit Journal</h3></div>
                 <div className="sm:ml-auto w-full sm:w-72"><select value={historyFilter} onChange={(e) => setHistoryFilter(e.target.value as any)} className={commonDropdownClass} style={commonDropdownStyle}><option value="ALL">Entire Event Pipeline</option><option value="STOCK">Inventory</option><option value="TRANSFER">Transfers</option><option value="USER">Auth</option><option value="REQUEST">Campaigns</option></select></div>
             </div>
             <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
               <table className="w-full text-left min-w-[700px]">
                  <thead className="bg-gray-50 border-b border-gray-100"><tr><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Class</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase">Operation</th><th className="px-6 py-4 text-xs font-black text-gray-500 uppercase text-right">Time</th></tr></thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredLogs.map(log => (
                      <tr key={log.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4"><span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase border ${log.category === 'STOCK' ? 'bg-purple-50 text-purple-700 border-purple-100' : log.category === 'USER' ? 'bg-blue-50 text-blue-700 border-blue-100' : log.category === 'TRANSFER' ? 'bg-yellow-50 text-yellow-700 border-yellow-100' : 'bg-orange-50 text-orange-700 border-orange-100'}`}>{log.category}</span></td>
                        <td className="px-6 py-4"><p className="text-xs text-gray-800 font-bold leading-tight">{log.details}</p><p className="text-[10px] text-gray-400 font-bold mt-1 uppercase">Auth: {log.performerName}</p></td>
                        <td className="px-6 py-4 text-right text-[10px] text-gray-400 font-black uppercase whitespace-nowrap">{new Date(log.timestamp).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</td>
                      </tr>
                    ))}
                  </tbody>
               </table>
             </div>
          </div>
        )}

      <ConfirmModal isOpen={confirmModal.isOpen} onClose={() => setConfirmModal(prev => ({...prev, isOpen: false}))} onConfirm={confirmModal.onConfirm} title={confirmModal.title} message={confirmModal.message} isDanger={confirmModal.isDanger} confirmText="Confirm" />
      <EmergencyMatchModal isOpen={emergencyMatchModal.isOpen} onClose={() => setEmergencyMatchModal(prev => ({...prev, isOpen: false}))} matchedDonors={emergencyMatchModal.matchedDonors} bloodType={emergencyMatchModal.bloodType} urgency={emergencyMatchModal.urgency} onNotifyDonor={handleNotifyDonor} />
    </div>
  );
};

export default AdminDashboard;