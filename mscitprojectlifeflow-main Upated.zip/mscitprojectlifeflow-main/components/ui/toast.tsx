import React, { useEffect } from 'react';
import { X, RotateCcw, CircleCheck as CheckCircle, CircleAlert as AlertCircle } from 'lucide-react';

export interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'error' | 'info';
  onUndo?: () => void;
}

interface ToastProps {
  toast: ToastMessage;
  onDismiss: (id: string) => void;
}

const Toast: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 6000); // 6 seconds to undo
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  return (
    <div className="flex items-center gap-3 bg-gray-900 text-white px-4 py-3 rounded-xl shadow-2xl shadow-gray-400/20 animate-slide-up min-w-[320px] justify-between border border-gray-800">
      <div className="flex items-center gap-3">
         {toast.type === 'error' ? <AlertCircle className="w-5 h-5 text-red-500" /> : <CheckCircle className="w-5 h-5 text-green-500" />}
         <span className="text-sm font-bold">{toast.message}</span>
      </div>
      
      <div className="flex items-center gap-3 pl-4 border-l border-gray-700 ml-2">
        {toast.onUndo && (
          <button 
            onClick={() => { toast.onUndo?.(); onDismiss(toast.id); }}
            className="text-yellow-400 text-xs font-bold hover:text-yellow-300 flex items-center gap-1.5 uppercase tracking-wider transition-colors"
          >
            <RotateCcw className="w-3 h-3" /> Undo
          </button>
        )}
        <button onClick={() => onDismiss(toast.id)} className="text-gray-500 hover:text-white transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default Toast;