/*
  # LifeFlow Blood Donation Platform Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `username` (text, unique, not null)
      - `password` (text, not null)
      - `full_name` (text, not null)
      - `role` (text, not null) - DONOR, BANK, ADMIN
      - `avatar_url` (text)
      - `blood_type` (text)
      - `location` (text)
      - `coordinates` (jsonb) - {lat, lng}
      - `age` (integer)
      - `weight` (integer)
      - `phone` (text)
      - `last_donation_date` (date)
      - `total_donations` (integer, default 0)
      - `claimable_credits` (integer, default 0)
      - `created_at` (timestamptz, default now())
    
    - `blood_stock`
      - `id` (uuid, primary key)
      - `bank_id` (uuid, foreign key -> users)
      - `blood_type` (text, not null)
      - `component` (text, not null) - WHOLE_BLOOD, RBC, PLATELET, PLASMA
      - `units` (integer, not null, default 0)
      - `last_updated` (timestamptz, default now())
    
    - `donation_requests`
      - `id` (uuid, primary key)
      - `bank_id` (uuid, foreign key -> users)
      - `bank_name` (text, not null)
      - `blood_type` (text, not null)
      - `urgency` (text, not null) - URGENT, NORMAL
      - `location` (text)
      - `coordinates` (jsonb)
      - `date` (date, not null)
      - `status` (text, not null) - OPEN, FULFILLED
      - `pledged_donor_ids` (jsonb, default '[]')
      - `notified_donor_ids` (jsonb, default '[]')
      - `created_at` (timestamptz, default now())
    
    - `blood_transfers`
      - `id` (uuid, primary key)
      - `source_bank_id` (uuid, foreign key -> users)
      - `source_bank_name` (text, not null)
      - `dest_bank_id` (uuid, foreign key -> users)
      - `dest_bank_name` (text, not null)
      - `blood_type` (text, not null)
      - `component` (text, not null)
      - `units` (integer, not null)
      - `status` (text, not null) - PENDING, APPROVED, REJECTED
      - `timestamp` (bigint, not null)
      - `initiated_by` (text, not null)
    
    - `stock_activities`
      - `id` (uuid, primary key)
      - `bank_id` (uuid, foreign key -> users)
      - `action` (text, not null)
      - `blood_type` (text, not null)
      - `component` (text, not null)
      - `units` (integer, not null)
      - `timestamp` (bigint, not null)
      - `related_person` (text)
      - `related_user_id` (uuid)
      - `person_type` (text)
    
    - `audit_logs`
      - `id` (uuid, primary key)
      - `action` (text, not null)
      - `details` (text, not null)
      - `performer_name` (text, not null)
      - `timestamp` (bigint, not null)
      - `type` (text, not null) - INFO, WARNING, SUCCESS

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add admin policies for system-wide access
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password text NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL,
  avatar_url text,
  blood_type text,
  location text,
  coordinates jsonb,
  age integer,
  weight integer,
  phone text,
  last_donation_date date,
  total_donations integer DEFAULT 0,
  claimable_credits integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create blood_stock table
CREATE TABLE IF NOT EXISTS blood_stock (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_id uuid REFERENCES users(id) ON DELETE CASCADE,
  blood_type text NOT NULL,
  component text NOT NULL,
  units integer NOT NULL DEFAULT 0,
  last_updated timestamptz DEFAULT now()
);

-- Create donation_requests table
CREATE TABLE IF NOT EXISTS donation_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_id uuid REFERENCES users(id) ON DELETE CASCADE,
  bank_name text NOT NULL,
  blood_type text NOT NULL,
  urgency text NOT NULL,
  location text,
  coordinates jsonb,
  date date NOT NULL,
  status text NOT NULL DEFAULT 'OPEN',
  pledged_donor_ids jsonb DEFAULT '[]'::jsonb,
  notified_donor_ids jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create blood_transfers table
CREATE TABLE IF NOT EXISTS blood_transfers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_bank_id uuid REFERENCES users(id) ON DELETE CASCADE,
  source_bank_name text NOT NULL,
  dest_bank_id uuid REFERENCES users(id) ON DELETE CASCADE,
  dest_bank_name text NOT NULL,
  blood_type text NOT NULL,
  component text NOT NULL,
  units integer NOT NULL,
  status text NOT NULL DEFAULT 'PENDING',
  timestamp bigint NOT NULL,
  initiated_by text NOT NULL
);

-- Create stock_activities table
CREATE TABLE IF NOT EXISTS stock_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_id uuid REFERENCES users(id) ON DELETE CASCADE,
  action text NOT NULL,
  blood_type text NOT NULL,
  component text NOT NULL,
  units integer NOT NULL,
  timestamp bigint NOT NULL,
  related_person text,
  related_user_id uuid,
  person_type text
);

-- Create audit_logs table
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action text NOT NULL,
  details text NOT NULL,
  performer_name text NOT NULL,
  timestamp bigint NOT NULL,
  type text NOT NULL
);

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE blood_stock ENABLE ROW LEVEL SECURITY;
ALTER TABLE donation_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE blood_transfers ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can read all users"
  ON users FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can read all users (anon)"
  ON users FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Users can insert users"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can insert users (anon)"
  ON users FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can update all users"
  ON users FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can update all users (anon)"
  ON users FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete users"
  ON users FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Users can delete users (anon)"
  ON users FOR DELETE
  TO anon
  USING (true);

-- RLS Policies for blood_stock
CREATE POLICY "Anyone can read blood stock"
  ON blood_stock FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Banks can manage their stock"
  ON blood_stock FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for donation_requests
CREATE POLICY "Anyone can read donation requests"
  ON donation_requests FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can manage donation requests"
  ON donation_requests FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for blood_transfers
CREATE POLICY "Anyone can read transfers"
  ON blood_transfers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can manage transfers"
  ON blood_transfers FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for stock_activities
CREATE POLICY "Anyone can read activities"
  ON stock_activities FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can create activities"
  ON stock_activities FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- RLS Policies for audit_logs
CREATE POLICY "Anyone can read audit logs"
  ON audit_logs FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can create audit logs"
  ON audit_logs FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Insert initial demo users
INSERT INTO users (id, username, password, full_name, role, phone, coordinates)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', 'admin', '123', 'System Administrator', 'ADMIN', '+1-555-0101', '{"lat": 40.7588, "lng": -73.9851}'),
  ('550e8400-e29b-41d4-a716-446655440002', 'redcross_ny', '123', 'Red Cross New York', 'BANK', '+1-555-0202', '{"lat": 40.7588, "lng": -73.9851}'),
  ('550e8400-e29b-41d4-a716-446655440003', 'johndoe', '123', 'John Doe', 'DONOR', '+1-555-0303', '{"lat": 40.6782, "lng": -73.9442}'),
  ('550e8400-e29b-41d4-a716-446655440004', 'janesmith', '123', 'Jane Smith', 'DONOR', '+1-555-0404', '{"lat": 40.7282, "lng": -73.7949}'),
  ('550e8400-e29b-41d4-a716-446655440005', 'universal', '123', 'Emergency Sam', 'DONOR', '+1-555-9999', '{"lat": 40.7831, "lng": -73.9712}')
ON CONFLICT (id) DO NOTHING;

-- Update donor-specific fields
UPDATE users SET 
  blood_type = 'O+',
  location = 'Brooklyn, NY',
  age = 28,
  weight = 75,
  total_donations = 5,
  claimable_credits = 2,
  last_donation_date = '2023-11-15'
WHERE username = 'johndoe';

UPDATE users SET 
  blood_type = 'A-',
  location = 'Queens, NY',
  age = 32,
  weight = 62,
  total_donations = 2,
  claimable_credits = 0,
  last_donation_date = '2024-01-10'
WHERE username = 'janesmith';

UPDATE users SET 
  blood_type = 'O-',
  location = 'Upper West Side, NY',
  total_donations = 10,
  claimable_credits = 5
WHERE username = 'universal';

UPDATE users SET 
  location = 'Manhattan, NY'
WHERE username = 'redcross_ny';

-- Insert initial stock data
INSERT INTO blood_stock (bank_id, blood_type, component, units)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440002', 'O+', 'WHOLE_BLOOD', 12),
  ('550e8400-e29b-41d4-a716-446655440002', 'A-', 'PLASMA', 5)
ON CONFLICT DO NOTHING;

-- Insert initial donation request
INSERT INTO donation_requests (bank_id, bank_name, blood_type, urgency, location, coordinates, date, status)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440002', 'Red Cross New York', 'O+', 'URGENT', 'Manhattan, NY', '{"lat": 40.7588, "lng": -73.9851}', '2024-05-20', 'OPEN')
ON CONFLICT DO NOTHING;
