
import React, { useState, useEffect } from 'react';
import Dashboard from './components/dashboard';
import Login from './components/login';
import Toast, { ToastMessage } from './components/ui/toast';
import { User, BloodStock, DonationRequest, StockActivity, AuditLog, UserRole, BloodComponent, BloodTransfer } from './types';
import { DEFAULT_PASSWORD } from './constants';
import { supabase } from './lib/supabase';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [stock, setStock] = useState<BloodStock[]>([]);
  const [requests, setRequests] = useState<DonationRequest[]>([]);
  const [transfers, setTransfers] = useState<BloodTransfer[]>([]);
  const [activities, setActivities] = useState<StockActivity[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [loading, setLoading] = useState(true);

  // Map database fields to app fields
  const mapDbUserToUser = (dbUser: any): User => ({
    id: dbUser.id,
    username: dbUser.username,
    password: dbUser.password,
    fullName: dbUser.full_name,
    role: dbUser.role as UserRole,
    avatarUrl: dbUser.avatar_url,
    // Fix: Object literal may only specify known properties, but 'blood_type' does not exist in type 'User'.
    bloodType: dbUser.blood_type,
    location: dbUser.location,
    coordinates: dbUser.coordinates,
    age: dbUser.age,
    weight: dbUser.weight,
    phone: dbUser.phone,
    lastDonationDate: dbUser.last_donation_date,
    totalDonations: dbUser.total_donations,
    claimableCredits: dbUser.claimable_credits
  });

  const mapDbStockToStock = (dbStock: any): BloodStock => ({
    id: dbStock.id,
    bankId: dbStock.bank_id,
    bloodType: dbStock.blood_type,
    component: dbStock.component as BloodComponent,
    units: dbStock.units,
    lastUpdated: dbStock.last_updated
  });

  const mapDbRequestToRequest = (dbRequest: any): DonationRequest => ({
    id: dbRequest.id,
    bankName: dbRequest.bank_name,
    bloodType: dbRequest.blood_type,
    urgency: dbRequest.urgency as 'URGENT' | 'NORMAL',
    location: dbRequest.location,
    coordinates: dbRequest.coordinates,
    date: dbRequest.date,
    status: dbRequest.status as 'OPEN' | 'FULFILLED',
    pledgedDonorIds: dbRequest.pledged_donor_ids || []
  });

  const mapDbTransferToTransfer = (dbTransfer: any): BloodTransfer => ({
    id: dbTransfer.id,
    sourceBankId: dbTransfer.source_bank_id,
    sourceBankName: dbTransfer.source_bank_name,
    destBankId: dbTransfer.dest_bank_id,
    destBankName: dbTransfer.dest_bank_name,
    bloodType: dbTransfer.blood_type,
    component: dbTransfer.component as BloodComponent,
    units: dbTransfer.units,
    status: dbTransfer.status as 'PENDING' | 'APPROVED' | 'REJECTED',
    timestamp: dbTransfer.timestamp,
    initiatedBy: dbTransfer.initiated_by as UserRole
  });

  const mapDbActivityToActivity = (dbActivity: any): StockActivity => ({
    id: dbActivity.id,
    bankId: dbActivity.bank_id,
    action: dbActivity.action as 'ADD' | 'REMOVE' | 'CONVERT' | 'TRANSFER_OUT' | 'TRANSFER_IN',
    bloodType: dbActivity.blood_type,
    component: dbActivity.component as BloodComponent,
    units: dbActivity.units,
    timestamp: dbActivity.timestamp,
    relatedPerson: dbActivity.related_person,
    relatedUserId: dbActivity.related_user_id,
    personType: dbActivity.person_type as 'REGISTERED' | 'UNREGISTERED' | 'HOSPITAL' | 'BANK'
  });

  const mapDbLogToLog = (dbLog: any): AuditLog => ({
    id: dbLog.id,
    action: dbLog.action,
    details: dbLog.details,
    // Fix: Object literal may only specify known properties, but 'performer_name' does not exist in type 'AuditLog'.
    performerName: dbLog.performer_name,
    timestamp: dbLog.timestamp,
    type: dbLog.type as 'INFO' | 'WARNING' | 'SUCCESS'
  });

  // Load initial data from Supabase
  useEffect(() => {
    const loadData = async () => {
      try {
        const [usersRes, stockRes, requestsRes, transfersRes, activitiesRes, logsRes] = await Promise.all([
          supabase.from('users').select('*'),
          supabase.from('blood_stock').select('*'),
          supabase.from('donation_requests').select('*'),
          supabase.from('blood_transfers').select('*'),
          supabase.from('stock_activities').select('*').order('timestamp', { ascending: false }),
          supabase.from('audit_logs').select('*').order('timestamp', { ascending: false })
        ]);

        if (usersRes.data) setUsers(usersRes.data.map(mapDbUserToUser));
        if (stockRes.data) setStock(stockRes.data.map(mapDbStockToStock));
        if (requestsRes.data) setRequests(requestsRes.data.map(mapDbRequestToRequest));
        if (transfersRes.data) setTransfers(transfersRes.data.map(mapDbTransferToTransfer));
        if (activitiesRes.data) setActivities(activitiesRes.data.map(mapDbActivityToActivity));
        if (logsRes.data) setLogs(logsRes.data.map(mapDbLogToLog));
      } catch (error) {
        console.error('Error loading data:', error);
        addToast('Failed to load data', 'error');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'info', onUndo?: () => void) => {
    const id = Date.now().toString() + Math.random();
    setToasts(prev => [...prev, { id, message, type, onUndo }]);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleLogin = async (username: string) => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .maybeSingle();

    if (data) {
      const user = mapDbUserToUser(data);
      setCurrentUser(user);
      addToast(`Access Granted: ${user.fullName}`, 'success');
    } else {
      addToast('Authentication failed', 'error');
    }
  };

  const handleLogout = () => setCurrentUser(null);

  // Added handleForgotPassword implementation to meet Login component requirements
  const handleForgotPassword = async (username: string): Promise<boolean> => {
    const { data, error } = await supabase
      .from('users')
      .update({ password: DEFAULT_PASSWORD })
      .eq('username', username)
      .select()
      .maybeSingle();

    if (data) {
      setUsers(prev => prev.map(u => u.id === data.id ? mapDbUserToUser(data) : u));
      addToast(`Security credentials reset for ${data.full_name || username}`, 'success');
      return true;
    } else {
      addToast('Username not recognized in system', 'error');
      return false;
    }
  };

  const handleAddUser = async (newUser: User) => {
    const { data, error } = await supabase
      .from('users')
      .insert([{
        username: newUser.username,
        password: newUser.password || DEFAULT_PASSWORD,
        full_name: newUser.fullName,
        role: newUser.role,
        // Fix: Property 'avatar_url' does not exist on type 'User'.
        avatar_url: newUser.avatarUrl,
        // Fix: Property 'blood_type' does not exist on type 'User'.
        blood_type: newUser.bloodType,
        location: newUser.location,
        coordinates: newUser.coordinates,
        age: newUser.age,
        weight: newUser.weight,
        phone: newUser.phone,
        total_donations: 0,
        claimable_credits: 0
      }])
      .select()
      .single();

    if (data) {
      setUsers(prev => [...prev, mapDbUserToUser(data)]);
      addToast(`New user ${newUser.username} registered`, 'success');
    } else {
      addToast('Failed to add user', 'error');
    }
  };

  const handleUpdateUser = async (updatedUser: User) => {
    const { data, error } = await supabase
      .from('users')
      .update({
        username: updatedUser.username,
        password: updatedUser.password,
        full_name: updatedUser.fullName,
        role: updatedUser.role,
        avatar_url: updatedUser.avatarUrl,
        // Fix: Property 'blood_type' does not exist on type 'User'.
        blood_type: updatedUser.bloodType,
        location: updatedUser.location,
        coordinates: updatedUser.coordinates,
        age: updatedUser.age,
        weight: updatedUser.weight,
        phone: updatedUser.phone,
        last_donation_date: updatedUser.lastDonationDate,
        total_donations: updatedUser.totalDonations,
        claimable_credits: updatedUser.claimableCredits
      })
      .eq('id', updatedUser.id)
      .select()
      .single();

    if (data) {
      setUsers(prev => prev.map(u => u.id === data.id ? mapDbUserToUser(data) : u));
      if (currentUser?.id === data.id) setCurrentUser(mapDbUserToUser(data));
      addToast('Profile records updated', 'success');
    } else {
      addToast('Failed to update user', 'error');
    }
  };

  const handleDeleteUser = async (id: string) => {
    const { error } = await supabase.from('users').delete().eq('id', id);

    if (!error) {
      setUsers(prev => prev.filter(u => u.id !== id));
      addToast('User account archived', 'info');
    } else {
      addToast('Failed to delete user', 'error');
    }
  };

  const handleResetPassword = async (id: string) => {
    const { data, error } = await supabase
      .from('users')
      .update({ password: DEFAULT_PASSWORD })
      .eq('id', id)
      .select()
      .single();

    if (data) {
      setUsers(prev => prev.map(u => u.id === id ? mapDbUserToUser(data) : u));
      addToast('Security reset complete', 'success');
    } else {
      addToast('Failed to reset password', 'error');
    }
  };

  const handleStockTransaction = async (
    bankId: string,
    bloodType: string,
    units: number,
    action: 'ADD' | 'REMOVE',
    relatedPerson: string = 'Unknown',
    personType: 'REGISTERED' | 'UNREGISTERED' | 'HOSPITAL' | 'BANK' = 'UNREGISTERED',
    relatedUserId?: string,
    component: BloodComponent = 'WHOLE_BLOOD'
  ) => {
    // Update stock
    const existing = stock.find(s => s.bankId === bankId && s.bloodType === bloodType && s.component === component);

    if (existing) {
      const newUnits = action === 'ADD' ? existing.units + units : Math.max(0, existing.units - units);
      const { data, error } = await supabase
        .from('blood_stock')
        .update({ units: newUnits, last_updated: new Date().toISOString() })
        .eq('id', existing.id)
        .select()
        .single();

      if (data) {
        setStock(prev => prev.map(s => s.id === data.id ? mapDbStockToStock(data) : s));
      }
    } else if (action === 'ADD') {
      const { data, error } = await supabase
        .from('blood_stock')
        .insert([{ bank_id: bankId, blood_type: bloodType, component, units }])
        .select()
        .single();

      if (data) {
        setStock(prev => [...prev, mapDbStockToStock(data)]);
      }
    }

    // Add activity
    const { data: activityData } = await supabase
      .from('stock_activities')
      .insert([{
        bank_id: bankId,
        action,
        blood_type: bloodType,
        component,
        units,
        timestamp: Date.now(),
        related_person: relatedPerson,
        related_user_id: relatedUserId,
        person_type: personType
      }])
      .select()
      .single();

    if (activityData) {
      setActivities(prev => [mapDbActivityToActivity(activityData), ...prev]);
    }

    // Update donor stats if registered
    if (personType === 'REGISTERED' && relatedUserId) {
      const donor = users.find(u => u.id === relatedUserId);
      if (donor) {
        const updates: any = {};
        if (action === 'ADD') {
          updates.total_donations = (donor.totalDonations || 0) + units;
          updates.claimable_credits = (donor.claimableCredits || 0) + units;
          updates.last_donation_date = new Date().toISOString().split('T')[0];
        } else {
          const creditsToDeduct = Math.min((donor.claimableCredits || 0), units);
          updates.claimable_credits = Math.max(0, (donor.claimableCredits || 0) - creditsToDeduct);
        }

        const { data: updatedUser } = await supabase
          .from('users')
          .update(updates)
          .eq('id', relatedUserId)
          .select()
          .single();

        if (updatedUser) {
          setUsers(prev => prev.map(u => u.id === updatedUser.id ? mapDbUserToUser(updatedUser) : u));
        }
      }
    }

    addToast(action === 'ADD' ? 'Inventory replenished' : 'Inventory issued', 'success');
  };

  const handleTransferRequest = async (transfer: Omit<BloodTransfer, 'id' | 'status' | 'timestamp' | 'sourceBankName' | 'destBankName'>) => {
    const source = users.find(u => u.id === transfer.sourceBankId);
    const destination = users.find(u => u.id === transfer.destBankId);

    if (!source || !destination) return;

    const status = transfer.initiatedBy === UserRole.ADMIN ? 'APPROVED' : 'PENDING';
    const timestamp = Date.now();

    const { data, error } = await supabase
      .from('blood_transfers')
      .insert([{
        source_bank_id: transfer.sourceBankId,
        source_bank_name: source.fullName,
        dest_bank_id: transfer.destBankId,
        dest_bank_name: destination.fullName,
        blood_type: transfer.bloodType,
        component: transfer.component,
        units: transfer.units,
        status,
        timestamp,
        initiated_by: transfer.initiatedBy
      }])
      .select()
      .single();

    if (data) {
      const newTransfer = mapDbTransferToTransfer(data);
      setTransfers(prev => [newTransfer, ...prev]);

      if (status === 'APPROVED') {
        await finalizeTransfer(newTransfer);
      } else {
        addToast('Transfer request submitted to Admin', 'info');
        await supabase.from('audit_logs').insert([{
          action: 'TRANSFER_REQUEST',
          details: `${newTransfer.units}u of ${newTransfer.bloodType} ${newTransfer.component} from ${newTransfer.sourceBankName} to ${newTransfer.destBankName}`,
          performer_name: source.fullName,
          timestamp: Date.now(),
          type: 'INFO'
        }]);
      }
    }
  };

  const finalizeTransfer = async (transfer: BloodTransfer) => {
    await handleStockTransaction(
      transfer.sourceBankId, transfer.bloodType, transfer.units, 'REMOVE',
      transfer.destBankName, 'BANK', transfer.destBankId, transfer.component
    );
    await handleStockTransaction(
      transfer.destBankId, transfer.bloodType, transfer.units, 'ADD',
      transfer.sourceBankName, 'BANK', transfer.sourceBankId, transfer.component
    );

    const { data: logData } = await supabase.from('audit_logs').insert([{
      action: 'TRANSFER_APPROVAL',
      details: `Finalized transfer of ${transfer.units}u ${transfer.bloodType} to ${transfer.destBankName}`,
      performer_name: currentUser?.role === UserRole.ADMIN ? 'Administrator' : transfer.sourceBankName,
      timestamp: Date.now(),
      type: 'SUCCESS'
    }]).select().single();

    if (logData) {
      setLogs(prev => [mapDbLogToLog(logData), ...prev]);
    }

    addToast('Blood transfer completed successfully', 'success');
  };

  const handleApproveTransfer = async (id: string) => {
    const transfer = transfers.find(t => t.id === id);
    if (!transfer) return;

    const { data, error } = await supabase
      .from('blood_transfers')
      .update({ status: 'APPROVED' })
      .eq('id', id)
      .select()
      .single();

    if (data) {
      setTransfers(prev => prev.map(t => t.id === id ? mapDbTransferToTransfer(data) : t));
      await finalizeTransfer(transfer);
    }
  };

  const handleRejectTransfer = async (id: string) => {
    const transfer = transfers.find(t => t.id === id);

    const { data, error } = await supabase
      .from('blood_transfers')
      .update({ status: 'REJECTED' })
      .eq('id', id)
      .select()
      .single();

    if (data) {
      setTransfers(prev => prev.map(t => t.id === id ? mapDbTransferToTransfer(data) : t));
      addToast('Transfer request rejected', 'error');

      await supabase.from('audit_logs').insert([{
        action: 'TRANSFER_REJECTION',
        details: `Admin rejected transfer from ${transfer?.sourceBankName}`,
        performer_name: 'Administrator',
        timestamp: Date.now(),
        type: 'WARNING'
      }]);
    }
  };

  const handleProcessWholeBlood = async (bankId: string, bloodType: string) => {
    const wholeItem = stock.find(s => s.bankId === bankId && s.bloodType === bloodType && s.component === 'WHOLE_BLOOD');
    if (!wholeItem || wholeItem.units < 1) return;

    // Decrease whole blood by 1
    await supabase
      .from('blood_stock')
      .update({ units: wholeItem.units - 1, last_updated: new Date().toISOString() })
      .eq('id', wholeItem.id);

    // Add 1 unit to each component
    const components: BloodComponent[] = ['RBC', 'PLATELET', 'PLASMA'];
    for (const comp of components) {
      const existingComp = stock.find(s => s.bankId === bankId && s.bloodType === bloodType && s.component === comp);

      if (existingComp) {
        await supabase
          .from('blood_stock')
          .update({ units: existingComp.units + 1, last_updated: new Date().toISOString() })
          .eq('id', existingComp.id);
      } else {
        await supabase
          .from('blood_stock')
          .insert([{ bank_id: bankId, blood_type: bloodType, component: comp, units: 1 }]);
      }
    }

    // Reload stock
    const { data: stockData } = await supabase.from('blood_stock').select('*');
    if (stockData) setStock(stockData.map(mapDbStockToStock));

    // Add log
    const { data: logData } = await supabase.from('audit_logs').insert([{
      action: 'COMPONENT_CONVERSION',
      details: `Processed 1 unit of ${bloodType} Whole Blood into components`,
      performer_name: currentUser?.fullName || 'Bank',
      timestamp: Date.now(),
      type: 'SUCCESS'
    }]).select().single();

    if (logData) {
      setLogs(prev => [mapDbLogToLog(logData), ...prev]);
    }

    addToast(`${bloodType} unit separated into components`, 'success');
  };

  const handleAddRequest = async (newRequest: DonationRequest) => {
    const bankId = currentUser?.id;
    if (!bankId) return;

    const { data, error } = await supabase
      .from('donation_requests')
      .insert([{
        bank_id: bankId,
        bank_name: currentUser.fullName,
        blood_type: newRequest.bloodType,
        urgency: newRequest.urgency,
        location: newRequest.location,
        coordinates: newRequest.coordinates,
        date: newRequest.date,
        status: 'OPEN'
      }])
      .select()
      .single();

    if (data) {
      setRequests(prev => [mapDbRequestToRequest(data), ...prev]);
      addToast('Emergency drive published', 'success');
    }
  };

  const handleUpdateRequest = async (updatedRequest: DonationRequest) => {
    const { data, error } = await supabase
      .from('donation_requests')
      .update({
        blood_type: updatedRequest.bloodType,
        urgency: updatedRequest.urgency,
        location: updatedRequest.location,
        coordinates: updatedRequest.coordinates,
        date: updatedRequest.date,
        status: updatedRequest.status
      })
      .eq('id', updatedRequest.id)
      .select()
      .single();

    if (data) {
      setRequests(prev => prev.map(r => r.id === data.id ? mapDbRequestToRequest(data) : r));
      addToast('Drive details updated', 'success');
    }
  };

  const handleDeleteRequest = async (id: string) => {
    const { error } = await supabase.from('donation_requests').delete().eq('id', id);

    if (!error) {
      setRequests(prev => prev.filter(r => r.id !== id));
      addToast('Drive archive updated', 'info');
    }
  };

  const handleRespondToRequest = async (reqId: string) => {
    if (!currentUser) return;

    const request = requests.find(r => r.id === reqId);
    if (!request) return;

    const currentPledges = request.pledgedDonorIds || [];
    if (currentPledges.includes(currentUser.id)) return;

    const { data, error } = await supabase
      .from('donation_requests')
      .update({ pledged_donor_ids: [...currentPledges, currentUser.id] })
      .eq('id', reqId)
      .select()
      .single();

    if (data) {
      setRequests(prev => prev.map(r => r.id === reqId ? mapDbRequestToRequest(data) : r));
      addToast('Pledge recorded. Thank you!', 'success');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 font-bold text-sm uppercase tracking-widest">Loading LifeFlow...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="font-sans text-gray-900">
      <div className="fixed bottom-6 left-6 z-[100] flex flex-col gap-2 pointer-events-none">
        <div className="pointer-events-auto flex flex-col gap-2">
           {toasts.map(toast => (
             <Toast key={toast.id} toast={toast} onDismiss={removeToast} />
           ))}
        </div>
      </div>

      {!currentUser ? (
        <Login onLogin={handleLogin} onForgotPassword={handleForgotPassword} />
      ) : (
        <Dashboard
          currentUser={currentUser}
          allUsers={users}
          stock={stock}
          requests={requests}
          activities={activities}
          transfers={transfers}
          logs={logs}
          onLogout={handleLogout}
          onAddUser={handleAddUser}
          onUpdateUser={handleUpdateUser}
          onDeleteUser={handleDeleteUser}
          onResetPassword={handleResetPassword}
          onStockTransaction={handleStockTransaction}
          onTransferRequest={handleTransferRequest}
          onApproveTransfer={handleApproveTransfer}
          onRejectTransfer={handleRejectTransfer}
          onAddRequest={handleAddRequest}
          onUpdateRequest={handleUpdateRequest}
          onDeleteRequest={handleDeleteRequest}
          onRespondToRequest={handleRespondToRequest}
          onProcessBlood={handleProcessWholeBlood}
        />
      )}
    </div>
  );
};

export default App;
